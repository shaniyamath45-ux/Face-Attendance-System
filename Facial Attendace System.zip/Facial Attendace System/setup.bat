@echo off
cd /d "%~dp0"
title Face Attendance System - Fast Setup & Launcher Generator
color 0B

echo ========================================================
echo   FACE ATTENDANCE SYSTEM - LIGHTNING FAST SETUP
echo ========================================================
echo.

:: Detect Python command (python or py)
set PY_CMD=
python --version >nul 2>&1
if %errorlevel% equ 0 (
    set PY_CMD=python
) else (
    py --version >nul 2>&1
    if %errorlevel% equ 0 (
        set PY_CMD=py
    )
)

if "%PY_CMD%"=="" (
    echo [ERROR] Python was not found on this PC!
    echo Please install Python 3.10 or 3.11 from python.org
    echo IMPORTANT: Check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

echo [1/4] Creating virtual environment (venv)...
if not exist "venv" (
    %PY_CMD% -m venv venv
)

echo [2/4] Activating venv and upgrading pip...
call venv\Scripts\activate.bat
python -m pip install --upgrade pip --quiet

echo [3/4] Installing required libraries (fast wheel mode)...
pip install pillow matplotlib opencv-python numpy --quiet
pip install dlib-bin --quiet
pip install face-recognition --no-deps --quiet
pip install face_recognition_models Click --quiet

echo [4/4] Initializing dataset folder and generating start_app.bat...
if not exist "dataset" mkdir dataset

:: Automatically generate an ultra-fast, windowless start_app.bat
(
    echo @echo off
    echo cd /d "%%~dp0"
    echo if exist "venv\Scripts\pythonw.exe" ^(
    echo     start "" "venv\Scripts\pythonw.exe" "gui.py"
    echo ^) else ^(
    echo     start "" pythonw "gui.py"
    echo ^)
) > start_app.bat

echo.
echo ========================================================
echo   SETUP COMPLETE! 
echo   - All libraries installed successfully.
echo   - "start_app.bat" generated automatically.
echo.
echo   You can now double-click "start_app.bat" to open 
echo   your Face Attendance System immediately!
echo ========================================================
pause