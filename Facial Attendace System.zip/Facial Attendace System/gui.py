import os
import sys
import csv
import calendar
import tempfile
import webbrowser
import base64
import smtplib
import ssl
import io
import shutil
import sqlite3
import threading
import subprocess
from datetime import datetime, date, timedelta

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from PIL import Image, ImageTk, ImageOps, ImageDraw
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication

try:
    from collect import collect_data
except ImportError:
    def collect_data(*args, **kwargs):
        print("collect_data fallback:", args, kwargs)

try:
    from main import start_attendance
except ImportError:
    def start_attendance():
        print("start_attendance fallback called")

# ----------------- PALETTE & DEFAULTS -----------------
BG = "#0f172a"
PANEL = "#1e293b"
BLUE = "#0ea5e9"
GREEN = "#22c55e"
RED = "#ef4444"
MUTED = "#94a3b8"
COFFEE = "#a16207"
COFFEE_BG = "#38240d"

DEFAULT_ADMIN_USER = os.getenv("ADMIN_USER", "Kamran")
DEFAULT_ADMIN_PASS = os.getenv("ADMIN_PASS", "Kamran@123")


# ----------------- DATABASE HELPERS -----------------
def db_connect():
    conn = sqlite3.connect("attendance.db")
    conn.execute("""CREATE TABLE IF NOT EXISTS attendance
        (name TEXT, usn TEXT, branch TEXT, sem TEXT, date TEXT, time TEXT, photo TEXT,
         UNIQUE(usn, date))""")
    conn.execute("""CREATE TABLE IF NOT EXISTS attendance_days
        (date TEXT PRIMARY KEY, started INTEGER NOT NULL DEFAULT 0,
         finalized INTEGER NOT NULL DEFAULT 0)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS attendance_meta
        (key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS student_emails
        (usn TEXT PRIMARY KEY, email TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS absent_email_log
        (usn TEXT, date TEXT, sent_time TEXT, mode TEXT,
         PRIMARY KEY (usn, date))""")

    conn.execute("INSERT OR IGNORE INTO attendance_meta(key,value) VALUES('tracking_start_date',?)",
                 (date.today().isoformat(),))
    conn.execute("INSERT OR IGNORE INTO attendance_meta(key,value) VALUES('sender_email','sniyamath661@gmail.com')")
    conn.execute("INSERT OR IGNORE INTO attendance_meta(key,value) VALUES('sender_password','')")
    conn.execute("INSERT OR IGNORE INTO attendance_meta(key,value) VALUES('auto_dispatch_time','11:30 AM')")
    conn.execute("INSERT OR IGNORE INTO attendance_meta(key,value) VALUES('auto_dispatch_enabled','1')")
    conn.commit()
    return conn


def get_meta(key, default=""):
    conn = db_connect()
    row = conn.execute("SELECT value FROM attendance_meta WHERE key=?", (key,)).fetchone()
    conn.close()
    return row[0] if row else default


def set_meta(key, value):
    conn = db_connect()
    conn.execute("INSERT OR REPLACE INTO attendance_meta(key, value) VALUES(?,?)", (key, str(value)))
    conn.commit()
    conn.close()


def has_absent_email_been_sent(usn, day_iso):
    conn = db_connect()
    row = conn.execute(
        "SELECT sent_time, mode FROM absent_email_log WHERE LOWER(usn)=LOWER(?) AND date=?",
        (usn.strip(), day_iso)
    ).fetchone()
    conn.close()
    return row


def log_absent_email_sent(usn, day_iso, mode="AUTO"):
    conn = db_connect()
    now_str = datetime.now().strftime("%I:%M:%S %p")
    conn.execute(
        "INSERT OR REPLACE INTO absent_email_log(usn, date, sent_time, mode) VALUES(?,?,?,?)",
        (usn.strip().lower(), day_iso, now_str, mode)
    )
    conn.commit()
    conn.close()


def get_today_auto_dispatch_summary(day_iso):
    conn = db_connect()
    rows = conn.execute(
        "SELECT sent_time FROM absent_email_log WHERE date=? AND mode='AUTO' ORDER BY sent_time ASC",
        (day_iso,)
    ).fetchall()
    conn.close()
    if rows:
        return len(rows), rows[0][0]
    return 0, None


def save_student_email(usn, email):
    if not usn:
        return
    conn = db_connect()
    conn.execute("INSERT OR REPLACE INTO student_emails(usn, email) VALUES(?,?)",
                 (usn.strip().lower(), email.strip()))
    conn.commit()
    conn.close()


def get_student_email(name, usn):
    conn = db_connect()
    row = conn.execute("SELECT email FROM student_emails WHERE LOWER(usn)=LOWER(?)",
                       (usn.strip(),)).fetchone()
    conn.close()
    return row[0] if row and row[0] else ""


def load_registered_students():
    result = []
    if not os.path.exists("students.csv"):
        return result
    try:
        with open("students.csv", newline="", encoding="utf-8-sig") as f:
            for row in csv.reader(f):
                if len(row) >= 4 and row[0].strip() and row[1].strip():
                    email = get_student_email(row[0].strip(), row[1].strip())
                    if not email and len(row) >= 5 and row[4].strip():
                        email = row[4].strip()
                    result.append((row[0].strip(), row[1].strip(), row[2].strip(), row[3].strip(), email))
    except OSError as exc:
        messagebox.showerror("Students", f"Could not read students.csv:\n{exc}")
    return result


def usn_sort_key(person):
    usn = str(person[1]).strip()
    digits = "".join(c for c in usn if c.isdigit())
    return (0, int(digits), usn.lower()) if digits else (1, 0, usn.lower())


def normalize_db_date(date_str):
    if not date_str:
        return ""
    date_str = str(date_str).strip()[:10]
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(date_str, fmt).date().isoformat()
        except ValueError:
            continue
    return date_str


def format_date(value):
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").strftime("%d-%m-%Y")
    except (ValueError, TypeError):
        pass
    try:
        return datetime.strptime(str(value)[:10], "%d-%m-%Y").strftime("%d-%m-%Y")
    except (ValueError, TypeError):
        return str(value)


def format_time(value):
    value = str(value or "").strip()
    for fmt in ("%H:%M:%S", "%H:%M:%S %p", "%I:%M:%S %p", "%H:%M"):
        try:
            return datetime.strptime(value, fmt).strftime("%I:%M:%S %p")
        except ValueError:
            continue
    return value


def parse_date(value):
    value = value.strip()
    for fmt in ("%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    raise ValueError("Use DD-MM-YYYY, e.g. 29-10-2026.")


def finalize_due_days():
    today = date.today()
    conn = db_connect()
    if datetime.now().hour >= 23:
        conn.execute("UPDATE attendance_days SET finalized=1 WHERE date=? AND started=1", (today.isoformat(),))
    conn.execute("UPDATE attendance_days SET finalized=1 WHERE date < ? AND started=1", (today.isoformat(),))
    conn.commit()
    conn.close()


def photo_for_student(name, usn, preferred_photo=""):
    if preferred_photo and os.path.exists(preferred_photo):
        return preferred_photo
    conn = db_connect()
    row = conn.execute(
        "SELECT photo FROM attendance WHERE LOWER(name)=LOWER(?) AND LOWER(usn)=LOWER(?) AND photo<>'' ORDER BY date DESC LIMIT 1",
        (name, usn)
    ).fetchone()
    conn.close()
    if row and row[0] and os.path.exists(row[0]):
        return row[0]
    folder = os.path.join('dataset', f"{name.strip().replace(' ', '_')}_{usn.strip()}")
    if os.path.isdir(folder):
        images = sorted(x for x in os.listdir(folder) if x.lower().endswith(('.jpg', '.jpeg', '.png')))
        if images:
            return os.path.join(folder, images[0])
    return ""


def get_attendance_map(start_date, end_date=None):
    if end_date is None:
        end_date = start_date
    start_iso = start_date.isoformat()
    end_iso = end_date.isoformat()

    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT name, usn, branch, sem, date, time, photo FROM attendance")
    rows = cur.fetchall()
    conn.close()

    result = {}
    for r in rows:
        d_iso = normalize_db_date(r[4])
        if d_iso and start_iso <= d_iso <= end_iso:
            key = (str(r[0]).strip().lower(), str(r[1]).strip().lower(), d_iso)
            result[key] = (r[0], r[1], r[2], r[3], d_iso, r[5], r[6])
    return result


def get_attendance_dates():
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT date FROM attendance")
    rows = cur.fetchall()
    conn.close()
    return {normalize_db_date(r[0]) for r in rows if r[0]}


def determine_status_and_time(student_name, student_usn, target_day, att_map, attendance_dates_set):
    target_iso = target_day.isoformat()
    today = date.today()

    rec = att_map.get((student_name.lower(), student_usn.lower(), target_iso))
    if rec:
        return "PRESENT", format_time(rec[5]), rec[6]

    if target_day.weekday() == 6 and target_day != today:
        return "HOLIDAY", "-", ""

    if target_day >= today:
        return "NOT RECORDED", "-", ""

    if target_iso in attendance_dates_set:
        return "ABSENT", "-", ""
    else:
        return "NOT RECORDED", "-", ""


def bind_clipboard_menu(widget):
    menu = tk.Menu(widget, tearoff=0)
    menu.add_command(label="Cut", command=lambda: widget.event_generate("<<Cut>>"))
    menu.add_command(label="Copy", command=lambda: widget.event_generate("<<Copy>>"))
    menu.add_command(label="Paste", command=lambda: widget.event_generate("<<Paste>>"))
    menu.add_separator()
    menu.add_command(label="Select All", command=lambda: (widget.select_range(0, tk.END), widget.icursor(tk.END)))
    widget.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))
    widget.bind("<Control-v>", lambda e: (widget.event_generate("<<Paste>>"), "break")[1])
    widget.bind("<Control-V>", lambda e: (widget.event_generate("<<Paste>>"), "break")[1])
    widget.bind("<Control-c>", lambda e: (widget.event_generate("<<Copy>>"), "break")[1])
    widget.bind("<Control-C>", lambda e: (widget.event_generate("<<Copy>>"), "break")[1])
    widget.bind("<Control-a>", lambda e: (widget.select_range(0, tk.END), widget.icursor(tk.END), "break")[2])
    widget.bind("<Control-A>", lambda e: (widget.select_range(0, tk.END), widget.icursor(tk.END), "break")[2])


# ----------------- HEADLESS / BACKGROUND AUTO-DISPATCH ENGINE -----------------
def run_headless_auto_absent_dispatch(mode="AUTO"):
    today = date.today()
    today_iso = today.isoformat()

    if get_meta("auto_dispatch_enabled", "1") != "1" and mode == "AUTO":
        return 0

    sender_email = get_meta("sender_email", "").strip()
    sender_pwd = get_meta("sender_password", "").strip()
    if not sender_email or not sender_pwd:
        return 0

    attendance_dates_set = get_attendance_dates()
    if today.weekday() == 6 and today_iso not in attendance_dates_set:
        return 0

    students = load_registered_students()
    att_map = get_attendance_map(today)

    to_notify = []
    for st in students:
        name, usn, branch, sem, email = st[0], st[1], st[2], st[3], st[4]
        if not email or "@" not in email:
            continue
        if (name.lower(), usn.lower(), today_iso) in att_map:
            continue
        if has_absent_email_been_sent(usn, today_iso) is not None:
            continue
        to_notify.append(st)

    if not to_notify:
        return 0

    sent_count = 0
    try:
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender_email, sender_pwd)
            for st in to_notify:
                name, usn, branch, sem, email = st[0], st[1], st[2], st[3], st[4]
                photo_path = photo_for_student(name, usn)
                has_photo = bool(photo_path and os.path.exists(photo_path))

                msg_root = MIMEMultipart("related")
                msg_root["From"] = f"Face Attendance System <{sender_email}>"
                msg_root["To"] = email
                msg_root["Subject"] = f"Automatic Absent Alert: {name} ({format_date(today_iso)})"

                msg_alt = MIMEMultipart("alternative")
                msg_root.attach(msg_alt)

                html = generate_absent_email_html(
                    sender_email, name, usn, branch, sem, format_date(today_iso), has_photo=has_photo
                )
                msg_alt.attach(MIMEText(html, "html"))

                if has_photo:
                    try:
                        with open(photo_path, "rb") as f_img:
                            mime_photo = MIMEImage(f_img.read())
                            mime_photo.add_header('Content-ID', '<student_photo>')
                            mime_photo.add_header('Content-Disposition', 'inline')
                            msg_root.attach(mime_photo)
                    except Exception:
                        pass

                server.sendmail(sender_email, email, msg_root.as_string())
                log_absent_email_sent(usn, today_iso, mode=mode)
                sent_count += 1
    except Exception as exc:
        print("Auto-absent dispatch warning:", exc)

    return sent_count


def register_windows_background_task(time_12h_str, enabled=True):
    if os.name != "nt":
        return
    task_name = "FaceAttendance_AutoAbsentDispatch"
    try:
        if not enabled:
            subprocess.run(["schtasks", "/Delete", "/TN", task_name, "/F"],
                           capture_output=True, text=True)
            return

        parsed = datetime.strptime(time_12h_str.strip(), "%I:%M %p")
        time_24h = parsed.strftime("%H:%M")

        script_path = os.path.abspath(__file__)
        work_dir = os.path.dirname(script_path)
        python_exe = sys.executable
        pythonw_exe = python_exe.replace("python.exe", "pythonw.exe")
        if not os.path.exists(pythonw_exe):
            pythonw_exe = python_exe

        bat_path = os.path.join(work_dir, "run_auto_absent.bat")
        with open(bat_path, "w", encoding="utf-8") as bf:
            bf.write(f'@echo off\ncd /d "{work_dir}"\n"{pythonw_exe}" "{script_path}" --auto-absent\n')

        subprocess.run([
            "schtasks", "/Create", "/F",
            "/SC", "DAILY",
            "/TN", task_name,
            "/TR", f'"{bat_path}"',
            "/ST", time_24h
        ], capture_output=True, text=True)
    except Exception as exc:
        print("Task scheduler registration note:", exc)


# ----------------- PDF, PRINT & CHART GENERATION -----------------
def generate_attendance_chart_bytes(present_count, absent_count, holiday_count=0):
    try:
        fig, ax = plt.subplots(figsize=(5.5, 2.0), dpi=130)
        fig.patch.set_facecolor('#0f172a')
        ax.set_facecolor('#0f172a')
        categories = ['Present', 'Absent', 'Holidays']
        values = [present_count, absent_count, holiday_count]
        colors = ['#22c55e', '#ef4444', '#f59e0b']

        bars = ax.barh(categories, values, color=colors, height=0.52, edgecolor='#334155')
        for bar in bars:
            w = bar.get_width()
            ax.text(w + 0.1, bar.get_y() + bar.get_height() / 2, f' {int(w)} Days',
                    ha='left', va='center', color='white', fontsize=9, fontweight='bold')

        ax.set_xlim(0, max(max(values) + 2, 5))
        ax.tick_params(colors='#94a3b8', labelsize=9)
        for spine in ax.spines.values():
            spine.set_color('#334155')
        ax.xaxis.grid(True, linestyle='--', alpha=0.3, color='#475569')
        plt.tight_layout()

        buf = io.BytesIO()
        plt.savefig(buf, format='png', facecolor=fig.get_facecolor(), bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)
        return buf.read()
    except Exception:
        return b""


def generate_pdf_report_bytes(student_name, usn, branch, semester, period_label,
                              present_cnt, total_working, absent_cnt, holiday_cnt,
                              percentage, log_rows):
    buf = io.BytesIO()
    with PdfPages(buf) as pdf:
        fig = plt.figure(figsize=(8.5, 11), dpi=150)
        fig.patch.set_facecolor('#ffffff')

        header_ax = fig.add_axes([0.08, 0.88, 0.84, 0.08])
        header_ax.set_facecolor('#0f172a')
        header_ax.text(0.5, 0.62, "OFFICIAL ATTENDANCE & PERFORMANCE REPORT",
                       color='white', fontsize=14, fontweight='bold', ha='center', va='center')
        header_ax.text(0.5, 0.28, f"Report Scope: {period_label} | Generated: {datetime.now().strftime('%d-%m-%Y %I:%M %p')}",
                       color='#38bdf8', fontsize=10, ha='center', va='center')
        header_ax.axis('off')

        info_ax = fig.add_axes([0.08, 0.73, 0.84, 0.13])
        info_ax.set_facecolor('#f8fafc')
        for spine in info_ax.spines.values():
            spine.set_color('#cbd5e1')
        info_ax.text(0.04, 0.72, f"Student Name: {student_name.upper()}", fontsize=11, fontweight='bold', color='#1e293b')
        info_ax.text(0.04, 0.40, f"USN: {usn}", fontsize=11, color='#0284c7', fontweight='bold')
        info_ax.text(0.04, 0.12, f"Branch: {branch.upper()}  |  Semester: {semester}", fontsize=10, color='#475569')

        status_color = '#16a34a' if percentage >= 75 else ('#d97706' if percentage >= 60 else '#dc2626')
        info_ax.text(0.72, 0.68, "Attendance Percentage", fontsize=10, color='#64748b', ha='center')
        info_ax.text(0.72, 0.32, f"{percentage:.1f}%", fontsize=20, fontweight='bold', color=status_color, ha='center')
        info_ax.set_xticks([])
        info_ax.set_yticks([])

        chart_ax = fig.add_axes([0.12, 0.50, 0.76, 0.19])
        chart_ax.set_facecolor('#f8fafc')
        categories = ['Present', 'Absent', 'Holidays']
        values = [present_cnt, absent_cnt, holiday_cnt]
        colors = ['#22c55e', '#ef4444', '#f59e0b']
        bars = chart_ax.barh(categories, values, color=colors, height=0.5, edgecolor='#94a3b8')
        for bar in bars:
            w = bar.get_width()
            chart_ax.text(w + 0.15, bar.get_y() + bar.get_height() / 2, f' {int(w)} Days',
                          va='center', ha='left', fontsize=9, fontweight='bold', color='#1e293b')
        chart_ax.set_xlim(0, max(max(values) + 3, 6))
        chart_ax.set_title(f"Attendance Statistics ({present_cnt} Attended / {total_working} Working Days | {holiday_cnt} Holidays)",
                           fontsize=10.5, fontweight='bold', color='#0f172a', pad=8)
        chart_ax.tick_params(colors='#475569', labelsize=9)
        chart_ax.spines['top'].set_visible(False)
        chart_ax.spines['right'].set_visible(False)
        chart_ax.xaxis.grid(True, linestyle='--', alpha=0.5, color='#cbd5e1')

        table_ax = fig.add_axes([0.08, 0.08, 0.84, 0.38])
        table_ax.axis('off')

        table_data = [["Date", "Status", "Recorded Timestamp"]]
        for r in log_rows[-12:]:
            table_data.append([r[0], r[1], r[2]])

        table = table_ax.table(cellText=table_data, loc='top', cellLoc='center', colWidths=[0.33, 0.33, 0.34])
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1, 1.45)
        for (row_idx, col_idx), cell in table.get_celld().items():
            if row_idx == 0:
                cell.set_facecolor('#0f172a')
                cell.get_text().set_color('white')
                cell.get_text().set_weight('bold')
            else:
                cell.set_facecolor('#f8fafc' if row_idx % 2 == 0 else '#ffffff')
                st_val = table_data[row_idx][1]
                if st_val == "PRESENT":
                    cell.get_text().set_color('#16a34a')
                    cell.get_text().set_weight('bold')
                elif st_val == "ABSENT":
                    cell.get_text().set_color('#dc2626')
                    cell.get_text().set_weight('bold')

        pdf.savefig(fig)
        plt.close(fig)

    buf.seek(0)
    return buf.read()


def generate_absent_email_html(sender_email, student_name, usn, branch, semester, absent_date, has_photo=False):
    photo_html = '<div style="text-align:center;margin-bottom:12px;"><img src="cid:student_photo" style="width:75px;height:75px;border-radius:50%;border:3px solid #ef4444;object-fit:cover;"></div>' if has_photo else ''
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<style>
    body {{ font-family: Arial, sans-serif; background: #f1f5f9; margin: 0; padding: 20px; }}
    .card {{ max-width: 540px; margin: auto; background: #fff; border-radius: 8px; overflow: hidden; border-top: 5px solid #ef4444; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }}
    .hdr {{ background: #0f172a; color: #fff; padding: 20px; text-align: center; }}
    .badge {{ background: #ef4444; color: #fff; padding: 4px 12px; border-radius: 14px; font-weight: bold; font-size: 12px; display: inline-block; margin-top: 8px; }}
    .body {{ padding: 24px; color: #334155; line-height: 1.5; font-size: 14px; }}
    table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
    td {{ padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 13px; }}
    .lbl {{ font-weight: bold; color: #64748b; width: 35%; }}
    .ftr {{ background: #f8fafc; text-align: center; padding: 12px; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; }}
</style></head>
<body>
<div class="card">
    <div class="hdr">
        <h2 style="margin:0;font-size:18px;">FACE ATTENDANCE NOTIFICATION</h2>
        <div class="badge">ABSENT ALERT</div>
    </div>
    <div class="body">
        {photo_html}
        <p>Dear Student / Parent,</p>
        <p>This is an official notice to inform you that <b>{student_name}</b> was recorded as <b>ABSENT</b> on <b>{absent_date}</b>.</p>
        <table>
            <tr><td class="lbl">Student Name:</td><td><b>{student_name}</b></td></tr>
            <tr><td class="lbl">USN:</td><td><b>{usn}</b></td></tr>
            <tr><td class="lbl">Branch / Sem:</td><td>{branch} - Semester {semester}</td></tr>
            <tr><td class="lbl">Date:</td><td><b>{absent_date}</b></td></tr>
            <tr><td class="lbl">Status:</td><td><b style="color:#ef4444;">ABSENT</b></td></tr>
        </table>
        <p style="font-size: 12px; color: #64748b;">If this absence was due to illness or an authorized event, please submit leave documentation.</p>
    </div>
    <div class="ftr">Automated Attendance Alert &bull; Sender: {sender_email}</div>
</div>
</body></html>"""


def generate_attendance_report_email_html(sender_email, student_name, usn, branch, semester, period_label,
                                          present_cnt, total_working, absent_cnt, holiday_cnt,
                                          percentage, log_rows, has_photo=False):
    status_color = "#22c55e" if percentage >= 75 else ("#f59e0b" if percentage >= 60 else "#ef4444")
    table_rows = "".join([f"<tr><td>{r[0]}</td><td><b>{r[1]}</b></td><td>{r[2]}</td></tr>" for r in log_rows[-10:]])
    photo_html = '<div style="text-align:center;margin-bottom:12px;"><img src="cid:student_photo" style="width:75px;height:75px;border-radius:50%;border:3px solid #0ea5e9;object-fit:cover;"></div>' if has_photo else ''
    total_calendar_days = total_working + holiday_cnt

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<style>
    body {{ font-family: Arial, sans-serif; background: #f1f5f9; margin: 0; padding: 20px; }}
    .card {{ max-width: 560px; margin: auto; background: #fff; border-radius: 8px; overflow: hidden; border-top: 5px solid #0ea5e9; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }}
    .hdr {{ background: #0f172a; color: #fff; padding: 20px; text-align: center; }}
    .badge {{ background: {status_color}; color: #fff; padding: 4px 12px; border-radius: 14px; font-weight: bold; font-size: 12px; display: inline-block; margin-top: 8px; }}
    .body {{ padding: 22px; color: #334155; line-height: 1.5; font-size: 14px; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 12px; }}
    th, td {{ padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; }}
    th {{ background: #f1f5f9; color: #475569; }}
    .pdf-note {{ background: #e0f2fe; border-left: 4px solid #0284c7; padding: 10px 12px; border-radius: 4px; font-size: 13px; color: #0369a1; margin: 15px 0; }}
    .ftr {{ background: #f8fafc; text-align: center; padding: 12px; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; }}
</style></head>
<body>
<div class="card">
    <div class="hdr">
        <h2 style="margin:0;font-size:18px;">ATTENDANCE PROGRESS REPORT</h2>
        <div class="badge">{period_label}: {percentage:.1f}% ATTENDANCE</div>
    </div>
    <div class="body">
        {photo_html}
        <p>Dear <b>{student_name}</b> ({usn}),</p>
        <p>Here is your verified attendance progress report for <b>{period_label}</b>:</p>

        <div class="pdf-note">
            📄 <b>Official PDF Report Attached:</b> A complete, printable PDF attendance report with graph has been attached to this email.
        </div>

        <table style="width:100%;margin-bottom:12px;font-size:13px;">
            <tr><td style="border:none;text-align:left;"><b>Branch:</b> {branch} (Sem {semester})</td>
                <td style="border:none;text-align:right;"><b>Attendance:</b> <span style="color:{status_color};font-weight:bold;font-size:16px;">{percentage:.1f}%</span></td></tr>
            <tr><td style="border:none;text-align:left;color:#64748b;" colspan="2">
                <b>Total Calendar Days:</b> {total_calendar_days} days ({total_working} working days, {holiday_cnt} Sunday holidays)<br>
                <b>Days Attended:</b> {present_cnt} &bull; <b>Absent / Unrecorded:</b> {absent_cnt}
            </td></tr>
        </table>

        <div style="text-align:center;margin:15px 0;">
            <img src="cid:attendance_chart" style="max-width:100%;border-radius:6px;border:1px solid #334155;">
        </div>

        <p style="margin-bottom:4px;font-weight:bold;color:#475569;">Attendance Session Log (Recent):</p>
        <table>
            <thead><tr><th>Date</th><th>Status</th><th>Recorded Time</th></tr></thead>
            <tbody>{table_rows}</tbody>
        </table>
    </div>
    <div class="ftr">Automated Attendance Report &bull; Sender: {sender_email}</div>
</div>
</body></html>"""


def open_print_report(title, headings, rows):
    def esc(v):
        return (str(v).replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))

    report_headings = list(headings)
    if "Photo" not in report_headings:
        report_headings.insert(0, "Photo")
    head = "".join(f"<th>{esc(h)}</th>" for h in report_headings)
    rendered_rows = []
    for row in rows:
        values = list(row)
        photo_html = "—"
        if len(values) >= 2:
            photo_path = photo_for_student(str(values[0]), str(values[1]))
            if photo_path and os.path.exists(photo_path):
                try:
                    with open(photo_path, "rb") as image_file:
                        encoded = base64.b64encode(image_file.read()).decode("ascii")
                    ext = os.path.splitext(photo_path)[1].lower()
                    mime = "image/png" if ext == ".png" else "image/jpeg"
                    photo_html = f'<img style="width:42px;height:42px;object-fit:cover;border-radius:4px;" src="data:{mime};base64,{encoded}">'
                except OSError:
                    pass
        cells = [f"<td>{photo_html}</td>"] + [f"<td>{esc(v)}</td>" for v in values]
        rendered_rows.append("<tr>" + "".join(cells) + "</tr>")
    body = "".join(rendered_rows)
    statuses = [str(row[5]).upper() for row in rows if len(row) > 5]
    summary_html = (f"<p><b>Total Rows:</b> {len(rows)} &nbsp; | &nbsp; "
                    f"<b>Present:</b> {statuses.count('PRESENT')} &nbsp; | &nbsp; "
                    f"<b>Absent:</b> {statuses.count('ABSENT')} &nbsp; | &nbsp; "
                    f"<b>Not Recorded:</b> {statuses.count('NOT RECORDED')} &nbsp; | &nbsp; "
                    f"<b>Holiday:</b> {statuses.count('HOLIDAY')}</p>")
    html = f"""<!doctype html><html><head><meta charset="utf-8"><title>{esc(title)}</title>
    <style>@page{{size:A4 landscape;margin:12mm}}body{{font:11px Arial, sans-serif;color:#0f172a}}h1{{font-size:19px;margin-bottom:6px}}
    .btn-bar{{margin-bottom:12px}}button{{padding:8px 14px;background:#0284c7;color:#fff;border:none;border-radius:4px;cursor:pointer;font-weight:bold;margin-right:8px}}
    table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #94a3b8;padding:6px;text-align:left}}
    th{{background:#e2e8f0}}@media print{{.btn-bar{{display:none}}}}</style></head><body>
    <div class="btn-bar">
        <button onclick="window.print()">Print / Save PDF (A4)</button>
        <button style="background:#475569" onclick="if (history.length > 1) history.back(); else window.close();">Close Report</button>
    </div>
    <h1>{esc(title)}</h1>
    {summary_html}<p>Generated: {datetime.now().strftime("%d-%m-%Y %I:%M:%S %p")}</p>
    <table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></body></html>"""
    path = os.path.join(tempfile.gettempdir(), "face_attendance_report.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    webbrowser.open("file://" + os.path.abspath(path))


# ----------------- MAIN ATTENDANCE APPLICATION -----------------
class AttendanceApp:
    def __init__(self, window):
        self.window = window
        window.title("Face Attendance System")
        window.geometry("1480x920")
        window.minsize(1100, 700)
        window.configure(bg=BG)

        self.active_child_window = None
        self.selected_day = date.today()
        self.last_report = ("Attendance Report", [], [])

        self._load_saved_email_settings()

        self.calendar_canvas = None
        self.calendar_scroll_area = None
        self.calendar_tree = None
        self.records_canvas = None
        self.records_scroll_area = None
        self.email_scroll_canvas = None
        self.change_scroll_canvas = None
        self._card_photo_refs = []
        self._calendar_photo_refs = []

        self._build()
        self.window.bind_all("<MouseWheel>", self._route_mousewheel, add="+")
        self.window.bind_all("<Button-4>", self._route_mousewheel, add="+")
        self.window.bind_all("<Button-5>", self._route_mousewheel, add="+")

        finalize_due_days()
        self.load_attendance()

        self.window.after(1500, self._check_and_run_auto_absent)
        self.window.after(30000, self._background_timer_tick)

    # ------------------ STRICT SINGLE-PAGE WINDOW NAVIGATION ------------------
    def _open_exclusive_page(self, create_func):
        """
        Hides the main window and ensures ONLY ONE feature page is visible at a time.
        When that feature page closes, the main window automatically returns.
        """
        if self.active_child_window is not None and self.active_child_window.winfo_exists():
            self.active_child_window.destroy()

        self.window.withdraw()

        def restore_main():
            self.active_child_window = None
            if self.window.winfo_exists():
                self.window.deiconify()
                self.window.lift()
                self.window.focus_force()
                self.load_attendance()

        win = create_func(on_close_callback=restore_main)
        self.active_child_window = win
        win.protocol("WM_DELETE_WINDOW", lambda: (win.destroy(), restore_main()))
        win.lift()
        win.focus_force()

    def _load_saved_email_settings(self):
        self.sender_email = get_meta("sender_email", "sniyamath661@gmail.com")
        self.sender_pwd = get_meta("sender_password", "")
        time_str = get_meta("auto_dispatch_time", "11:30 AM")
        self.auto_absent_enabled = (get_meta("auto_dispatch_enabled", "1") == "1")

        try:
            t = datetime.strptime(time_str.strip(), "%I:%M %p")
            self.auto_hour_24 = t.hour
            self.auto_min = t.minute
        except Exception:
            self.auto_hour_24 = 11
            self.auto_min = 30

    def _route_mousewheel(self, event):
        if getattr(event, "num", None) == 4:
            amount = -3
        elif getattr(event, "num", None) == 5:
            amount = 3
        else:
            amount = int(-1 * (event.delta / 120))
            if amount == 0:
                amount = -1 if event.delta > 0 else 1
            amount *= 3

        for canvas in (self.email_scroll_canvas, self.change_scroll_canvas, self.records_canvas, self.calendar_canvas):
            if canvas is not None and canvas.winfo_exists():
                canvas.yview_scroll(amount, "units")
                return "break"
        return None

    def _check_and_run_auto_absent(self):
        now = datetime.now()
        if self.auto_absent_enabled and self.sender_pwd and self.sender_email:
            if now.hour > self.auto_hour_24 or (now.hour == self.auto_hour_24 and now.minute >= self.auto_min):
                threading.Thread(target=run_headless_auto_absent_dispatch, args=("AUTO",), daemon=True).start()

    def _background_timer_tick(self):
        finalize_due_days()
        self._check_and_run_auto_absent()
        self.window.after(30000, self._background_timer_tick)

    def _build(self):
        self.shell = tk.Frame(self.window, bg=BG)
        self.shell.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(self.shell, bg="#111e2d", width=230)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        tk.Label(self.sidebar, text="🎓  FACE ATTENDANCE", bg="#111e2d", fg="white",
                 font=("Arial", 14, "bold"), wraplength=190).pack(pady=(24, 20), padx=10)

        for text, cmd, color in [
            ("＋  Add Student", lambda: self._open_exclusive_page(self.add_student_dialog), "#20364d"),
            ("▤  View Attendance", self.load_attendance, "#20364d"),
            ("📷  Start Attendance", self.start_camera_attendance, BLUE),
            ("▦  Calendar View", self.show_calendar, "#20364d"),
            ("🖨  Print Report", lambda: self._open_exclusive_page(self.print_report), "#38236b"),
            ("✉  Inform Absentees", lambda: self._open_exclusive_page(self.open_email_center), "#b45309"),
            ("⚙  Change Info", lambda: self._open_exclusive_page(self.open_change_info_login), "#334155"),
        ]:
            tk.Button(self.sidebar, text=text, command=cmd, bg=color, fg="white",
                      activebackground=BLUE, activeforeground="white", relief="flat",
                      anchor="w", padx=15, pady=12, font=("Arial", 10, "bold")
                      ).pack(fill="x", padx=12, pady=4)

        self.admin_footer_lbl = tk.Label(
            self.sidebar,
            text=f"Working days: Mon–Sat\nSunday: Holiday\nSender: {self.sender_email}",
            bg="#111e2d", fg="#fbbf24", font=("Arial", 9, "bold"),
            justify="left"
        )
        self.admin_footer_lbl.pack(side="bottom", anchor="w", padx=16, pady=20)

        self.content = tk.Frame(self.shell, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)

        header = tk.Frame(self.content, bg="#15283b")
        header.pack(fill="x", padx=10, pady=(10, 6))

        tk.Label(header, text="▥  STUDENT ATTENDANCE", bg="#15283b", fg="white",
                 font=("Arial", 22, "bold")).pack(side="left", padx=14, pady=16)

        self.clock_label = tk.Label(header, text="", bg="#15283b", fg="white",
                                    font=("Arial", 11, "bold"), justify="right")
        self.clock_label.pack(side="right", padx=15)
        self._update_clock()

        controls = tk.Frame(self.content, bg=BG)
        controls.pack(fill="x", padx=12, pady=5)
        tk.Label(controls, text="View:", bg=BG, fg="white", font=("Arial", 11, "bold")).pack(side="left", padx=4)
        self.filter_var = tk.StringVar(value="Today")
        self.filter_box = ttk.Combobox(controls, textvariable=self.filter_var, state="readonly", width=15,
                                       values=["Today", "This Week", "This Month", "This Year", "All Attendance"])
        self.filter_box.pack(side="left", padx=5)
        self.filter_box.bind("<<ComboboxSelected>>", lambda e: self.load_attendance())

        search = tk.Frame(self.content, bg=BG)
        search.pack(fill="x", padx=12, pady=5)
        self.entries = {}
        for label, key, width in [("Name", "name", 12), ("USN", "usn", 10), ("Branch", "branch", 10),
                                  ("Semester", "sem", 9), ("Date", "date", 11)]:
            tk.Label(search, text=label, bg=BG, fg="white").pack(side="left", padx=(5, 2))
            e = tk.Entry(search, width=width)
            e.pack(side="left", padx=2, ipady=4)
            self.entries[key] = e
            bind_clipboard_menu(e)

        tk.Button(search, text="🔍 Search", command=self.load_attendance, bg=BLUE, fg="white",
                  relief="flat", padx=15, pady=6).pack(side="left", padx=5)
        tk.Button(search, text="Clear", command=self.clear_search, bg="#334155", fg="white",
                  relief="flat", padx=12, pady=6).pack(side="left", padx=3)

        tk.Label(self.content, text="Date format: DD-MM-YYYY  |  Time format: 12-hour AM/PM",
                 bg=BG, fg=MUTED, font=("Arial", 9)).pack(anchor="w", padx=18)

        self.summary = tk.Frame(self.content, bg=BG)
        self.summary.pack(fill="x", padx=12, pady=8)
        self.total_label = self._summary_card(self.summary, "Total Students", "0", "#173454")
        self.present_label = self._summary_card(self.summary, "Present Today", "0", "#064e3b")
        self.absent_label = self._summary_card(self.summary, "Absent Today", "0", "#5b2028")
        self.holiday_label = self._summary_card(self.summary, "Weekly Rule", "Mon–Sat", "#164e63")
        self.holiday_card = self._summary_card(self.summary, "Sunday Status", "Active Today" if date.today().weekday() == 6 else "Holiday", "#713f12")

        self.info_label = tk.Label(self.content, text="", bg=BG, fg="#38bdf8",
                                   font=("Arial", 11, "bold"), anchor="w")
        self.info_label.pack(fill="x", padx=16, pady=(2, 5))

        self.body = tk.Frame(self.content, bg=BG)
        self.body.pack(fill="both", expand=True, padx=12, pady=5)
        self.records_frame = tk.Frame(self.body, bg=BG)
        self.records_frame.pack(fill="both", expand=True)
        self._build_calendar_controls()

        bottom = tk.Frame(self.content, bg=BG)
        bottom.pack(fill="x", padx=12, pady=8)
        tk.Button(bottom, text="🖨 Print A4 Report", command=lambda: self._open_exclusive_page(self.print_report),
                  bg="#6d28d9", fg="white", relief="flat", padx=15, pady=8).pack(side="left", padx=4)
        tk.Button(bottom, text="✉ Send Attendance Emails", command=lambda: self._open_exclusive_page(self.open_email_center),
                  bg="#b45309", fg="white", relief="flat", padx=15, pady=8).pack(side="left", padx=4)
        tk.Button(bottom, text="⚙ Change Student Info", command=lambda: self._open_exclusive_page(self.open_change_info_login),
                  bg="#334155", fg="white", relief="flat", padx=15, pady=8).pack(side="left", padx=4)
        tk.Button(bottom, text="🔄 Refresh", command=self.load_attendance,
                  bg="#334155", fg="white", relief="flat", padx=15, pady=8).pack(side="left", padx=4)
        tk.Button(bottom, text="✖ Close", command=self.window.destroy,
                  bg="#b91c1c", fg="white", relief="flat", padx=15, pady=8).pack(side="right", padx=4)

    def _summary_card(self, parent, title, value, color):
        card = tk.Frame(parent, bg=color, bd=1, relief="ridge")
        card.pack(side="left", fill="x", expand=True, padx=4)
        tk.Label(card, text=title, bg=color, fg="white", font=("Arial", 9, "bold")).pack(pady=(8, 2))
        val = tk.Label(card, text=value, bg=color, fg="white", font=("Arial", 15, "bold"))
        val.pack(pady=(0, 8))
        return val

    def _update_clock(self):
        now = datetime.now()
        self.clock_label.config(text=f"{now.strftime('%d-%m-%Y')}   {now.strftime('%I:%M:%S %p')}\n{now.strftime('%A')}")
        self.window.after(1000, self._update_clock)

    def _build_calendar_controls(self):
        self.cal_controls = tk.Frame(self.body, bg=BG)
        self.cal_controls.pack_forget()
        self.cal_year = tk.IntVar(value=date.today().year)
        self.cal_month = tk.StringVar(value=calendar.month_name[date.today().month])
        self.cal_day = tk.IntVar(value=date.today().day)
        tk.Label(self.cal_controls, text="Calendar:", bg=BG, fg="white").pack(side="left", padx=4)
        self.month_box = ttk.Combobox(self.cal_controls, textvariable=self.cal_month, values=list(calendar.month_name)[1:],
                                      state="readonly", width=12)
        self.month_box.pack(side="left", padx=4)
        self.year_box = ttk.Spinbox(self.cal_controls, from_=2000, to=2100, textvariable=self.cal_year, width=7)
        self.year_box.pack(side="left", padx=4)
        self.day_box = ttk.Spinbox(self.cal_controls, from_=1, to=31, textvariable=self.cal_day, width=4)
        self.day_box.pack(side="left", padx=4)
        tk.Button(self.cal_controls, text="Show Day", command=self.show_selected_day, bg=BLUE, fg="white").pack(side="left", padx=4)
        tk.Button(self.cal_controls, text="Show Week", command=self.show_selected_week, bg="#334155", fg="white").pack(side="left", padx=4)
        tk.Button(self.cal_controls, text="Show Month", command=self.show_calendar, bg="#334155", fg="white").pack(side="left", padx=4)

    def _clear_body(self):
        for w in self.records_frame.winfo_children():
            w.destroy()

    def _period_dates(self):
        today = date.today()
        selected = self.filter_var.get()
        if selected == "Today":
            return today, today
        if selected == "This Week":
            start = today - timedelta(days=today.weekday())
            return start, start + timedelta(days=6)
        if selected == "This Month":
            days_in_month = calendar.monthrange(today.year, today.month)[1]
            return date(today.year, today.month, 1), date(today.year, today.month, days_in_month)
        if selected == "This Year":
            return date(today.year, 1, 1), date(today.year, 12, 31)
        return date(2000, 1, 1), today

    def _matches_filters(self, student):
        for key, index in [("name", 0), ("usn", 1), ("branch", 2), ("sem", 3)]:
            value = self.entries[key].get().strip().lower()
            if value and value not in student[index].lower():
                return False
        return True

    def start_camera_attendance(self):
        self.window.withdraw()
        try:
            start_attendance()
        finally:
            self.window.deiconify()
            self.window.lift()
            self.load_attendance()

    # ------------------ ADD STUDENT (KEYBOARD ENTER FLOW + FULLSCREEN) ------------------
    def add_student_dialog(self, on_close_callback):
        dialog = tk.Toplevel(self.window)
        dialog.title("Add New Student")
        dialog.configure(bg=BG)
        dialog.geometry("760x540")
        dialog.minsize(560, 440)
        dialog.resizable(True, True)

        self._add_dialog_fullscreen = False

        def toggle_fullscreen():
            self._add_dialog_fullscreen = not self._add_dialog_fullscreen
            dialog.attributes("-fullscreen", self._add_dialog_fullscreen)

        dialog.bind("<F11>", lambda e: toggle_fullscreen())

        top_hdr = tk.Frame(dialog, bg="#15283b")
        top_hdr.pack(fill="x", padx=16, pady=(14, 10))
        tk.Label(top_hdr, text="➕ ADD STUDENT REGISTRATION", bg="#15283b", fg="white",
                 font=("Arial", 14, "bold")).pack(side="left", padx=12, pady=10)
        tk.Button(top_hdr, text="⛶ Fullscreen (F11)", command=toggle_fullscreen, bg="#0e7490", fg="white",
                  relief="flat", padx=10, pady=5, font=("Arial", 9, "bold")).pack(side="right", padx=12)

        tk.Label(dialog, text="Fill each field and press Enter on your keyboard to move down to the next field.",
                 bg=BG, fg=MUTED, font=("Arial", 9)).pack(pady=(0, 8))

        center_box = tk.Frame(dialog, bg=BG)
        center_box.pack(expand=True, fill="both", padx=45, pady=5)

        form = tk.Frame(center_box, bg=BG)
        form.pack(fill="x", pady=5)
        form.grid_columnconfigure(1, weight=1)

        entries = {}
        fields = [
            ("Student Name:", "name"),
            ("USN:", "usn"),
            ("Branch:", "branch"),
            ("Semester:", "sem"),
            ("Student/Parent Gmail:", "email"),
        ]

        for idx, (label_text, key) in enumerate(fields):
            tk.Label(form, text=label_text, bg=BG, fg="white", font=("Arial", 11, "bold")).grid(
                row=idx, column=0, sticky="w", pady=9
            )
            e = tk.Entry(form, font=("Arial", 11))
            e.grid(row=idx, column=1, sticky="ew", pady=9, padx=(14, 0), ipady=5)
            bind_clipboard_menu(e)
            entries[key] = e

        def submit():
            name = entries["name"].get().strip()
            usn = entries["usn"].get().strip()
            branch = entries["branch"].get().strip()
            sem = entries["sem"].get().strip()
            email = entries["email"].get().strip()

            if not (name and usn and branch and sem):
                messagebox.showerror("Missing Information", "Please fill Name, USN, Branch, and Semester.", parent=dialog)
                return

            existing = load_registered_students()
            for st in existing:
                if st[1].lower() == usn.lower():
                    messagebox.showerror("Already Added", f"Student with USN '{usn}' already exists as '{st[0]}'!", parent=dialog)
                    return

            with open("students.csv", "a", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow([name, usn, branch, sem])

            if email:
                save_student_email(usn, email)

            dialog.destroy()
            try:
                collect_data(name, usn, branch, sem)
            except TypeError:
                collect_data(name, usn, branch, sem, email)

            on_close_callback()

        field_order = ["name", "usn", "branch", "sem", "email"]
        for i, key in enumerate(field_order):
            if i < len(field_order) - 1:
                next_key = field_order[i + 1]
                entries[key].bind("<Return>", lambda e, nk=next_key: (entries[nk].focus_set(), "break")[1])
            else:
                entries[key].bind("<Return>", lambda e: (submit(), "break")[1])

        entries["name"].focus_set()

        btn_box = tk.Frame(center_box, bg=BG)
        btn_box.pack(fill="x", pady=(22, 10))
        tk.Button(btn_box, text="← Back to Main", command=lambda: (dialog.destroy(), on_close_callback()),
                  bg="#334155", fg="white", relief="flat", padx=16, pady=8, font=("Arial", 10)).pack(side="right", padx=(8, 0))
        tk.Button(btn_box, text="Save & Capture Face", command=submit, bg=BLUE, fg="white",
                  font=("Arial", 10, "bold"), relief="flat", padx=18, pady=8).pack(side="right")
        return dialog

    def load_attendance(self):
        self.calendar_canvas = None
        self.calendar_scroll_area = None
        self.records_canvas = None
        self.records_scroll_area = None
        self.cal_controls.pack_forget()
        self._clear_body()

        students = [s for s in sorted(load_registered_students(), key=usn_sort_key) if self._matches_filters(s)]
        all_students = load_registered_students()
        start_day, end_day = self._period_dates()
        date_text = self.entries["date"].get().strip()
        if date_text:
            try:
                one_day = date.fromisoformat(parse_date(date_text))
                start_day = end_day = one_day
            except ValueError as exc:
                messagebox.showerror("Invalid date", str(exc))
                return

        att_map = get_attendance_map(start_day, end_day)
        attendance_dates_set = get_attendance_dates()
        today = date.today()
        todays = get_attendance_map(today)
        present_keys = {(k[0], k[1]) for k in todays}
        present_count = sum((s[0].lower(), s[1].lower()) in present_keys for s in all_students)

        total_cal_days = (end_day - start_day).days + 1
        holiday_days = sum(
            1 for offset in range(total_cal_days)
            if (start_day + timedelta(days=offset)).weekday() == 6 and (start_day + timedelta(days=offset)) != today
        )
        working_days = total_cal_days - holiday_days

        self.total_label.config(text=str(len(all_students)))
        self.present_label.config(text=str(present_count))
        self.absent_label.config(text=(str(max(0, len(all_students) - present_count))
                                 if datetime.now().hour >= 23 else "Pending"))
        self.info_label.config(
            text=f"{self.filter_var.get()} ({total_cal_days} days: {working_days} working, {holiday_days} holidays)  |  "
                 f"Students: {len(students)}  |  Period: {format_date(start_day.isoformat())} – {format_date(end_day.isoformat())}"
        )

        headings = ["Name", "USN", "Branch", "Semester", "Date", "Status", "Time", "Gmail"]
        rows = []
        if self.filter_var.get() == "All Attendance" and not date_text:
            conn = db_connect()
            cur = conn.cursor()
            cur.execute("SELECT name, usn, MAX(branch), MAX(sem), date, MIN(time), MAX(photo) FROM attendance GROUP BY name, usn, date ORDER BY date DESC")
            db_rows = cur.fetchall()
            conn.close()
            for r in db_rows:
                student = (r[0], r[1], r[2], r[3])
                if self._matches_filters(student):
                    d_iso = normalize_db_date(r[4])
                    s_email = get_student_email(r[0], r[1])
                    rows.append([r[0], r[1], r[2], r[3], format_date(d_iso), "PRESENT", format_time(r[5]), s_email])
        else:
            for s in students:
                s_email = s[4] if len(s) >= 5 else ""
                day_iter = start_day
                while day_iter <= end_day:
                    status, time_val, _ = determine_status_and_time(s[0], s[1], day_iter, att_map, attendance_dates_set)
                    rows.append([s[0], s[1], s[2], s[3], format_date(day_iter.isoformat()), status, time_val, s_email])
                    day_iter += timedelta(days=1)

        self.last_report = (f"{self.filter_var.get()} Attendance Report", headings, rows)

        if not students:
            tk.Label(self.records_frame, text="No registered students match these filters.", bg=BG, fg="white",
                     font=("Arial", 13)).pack(pady=30)
            return
        self._render_table(headings, rows)

    def _render_table(self, headings, rows):
        container = tk.Frame(self.records_frame, bg=BG)
        container.pack(fill="both", expand=True)

        header_bar = tk.Frame(container, bg="#15283b", height=38, bd=1, relief="solid", highlightbackground="#31516b")
        header_bar.pack(fill="x", padx=10, pady=(4, 6))

        cols = [
            ("Photo", 70), ("#", 35), ("Name", 175), ("USN", 100),
            ("Branch", 80), ("Semester", 70), ("Date", 95), ("Status", 110), ("Time", 95), ("Gmail", 175)
        ]
        for name, width in cols:
            lbl = tk.Label(header_bar, text=name, bg="#15283b", fg="white", font=("Arial", 9, "bold"),
                           width=width // 9, anchor="center")
            lbl.pack(side="left", padx=3, pady=5)

        scroll_area = tk.Frame(container, bg=BG)
        scroll_area.pack(fill="both", expand=True, padx=8, pady=(0, 6))
        self.records_scroll_area = scroll_area

        canvas = tk.Canvas(scroll_area, bg=BG, highlightthickness=0)
        self.records_canvas = canvas
        vs = ttk.Scrollbar(scroll_area, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vs.set)

        vs.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        card_list = tk.Frame(canvas, bg=BG)
        win_id = canvas.create_window((0, 0), window=card_list, anchor="nw")

        def _on_config(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(win_id, width=canvas.winfo_width())

        card_list.bind("<Configure>", _on_config)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win_id, width=e.width))

        self._card_photo_refs.clear()
        status_colors = {
            "PRESENT": ("#064e3b", "#34d399", BLUE),
            "ABSENT": ("#5b2028", "#f87171", RED),
            "HOLIDAY": ("#713f12", "#fbbf24", "#d97706"),
            "NOT RECORDED": (COFFEE_BG, "#fef08a", COFFEE)
        }

        for idx, row in enumerate(rows, 1):
            name, usn, branch, sem, dt, status, tm = row[0], row[1], row[2], row[3], row[4], row[5], row[6]
            gmail = row[7] if len(row) > 7 and row[7] else "—"
            bg_card, text_color, border_highlight = status_colors.get(status, ("#1e293b", "#ffffff", "#475569"))

            card = tk.Frame(card_list, bg="#162232", bd=1, relief="solid",
                            highlightbackground=border_highlight, highlightthickness=1)
            card.pack(fill="x", padx=4, pady=4)

            photo_frame = tk.Frame(card, bg="#162232", width=70, height=56)
            photo_frame.pack(side="left", padx=(8, 2), pady=5)
            photo_frame.pack_propagate(False)

            photo_path = photo_for_student(name, usn)
            photo_thumb = None
            if photo_path and os.path.exists(photo_path):
                try:
                    im = Image.open(photo_path).convert("RGB")
                    im = ImageOps.fit(im, (42, 42), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
                    canvas_img = ImageOps.expand(im, border=2, fill=border_highlight)
                    draw = ImageDraw.Draw(canvas_img)
                    draw.rectangle((2, 2, 43, 43), outline="#e2e8f0", width=1)
                    photo_thumb = ImageTk.PhotoImage(canvas_img)
                    self._card_photo_refs.append(photo_thumb)
                except Exception:
                    photo_thumb = None

            if photo_thumb:
                pic_lbl = tk.Label(photo_frame, image=photo_thumb, bg="#162232")
            else:
                pic_lbl = tk.Label(photo_frame, text="No Pic", bg="#20364d", fg=MUTED,
                                   font=("Arial", 7), width=8, height=3, relief="solid", bd=1)
            pic_lbl.pack(expand=True)

            tk.Label(card, text=str(idx), bg="#162232", fg=MUTED, font=("Arial", 9, "bold"),
                     width=cols[1][1] // 9, anchor="center").pack(side="left", padx=3)
            tk.Label(card, text=name, bg="#162232", fg="white", font=("Arial", 9, "bold"),
                     width=cols[2][1] // 9, anchor="center").pack(side="left", padx=3)
            tk.Label(card, text=usn, bg="#162232", fg="#38bdf8", font=("Arial", 9),
                     width=cols[3][1] // 9, anchor="center").pack(side="left", padx=3)
            tk.Label(card, text=branch, bg="#162232", fg="white", font=("Arial", 9),
                     width=cols[4][1] // 9, anchor="center").pack(side="left", padx=3)
            tk.Label(card, text=sem, bg="#162232", fg="white", font=("Arial", 10),
                     width=cols[5][1] // 9, anchor="center").pack(side="left", padx=3)
            tk.Label(card, text=dt, bg="#162232", fg="white", font=("Arial", 9),
                     width=cols[6][1] // 9, anchor="center").pack(side="left", padx=3)

            status_container = tk.Frame(card, bg="#162232", width=cols[7][1])
            status_container.pack(side="left", padx=3)
            status_badge = tk.Label(status_container, text=status, bg=bg_card, fg=text_color,
                                    font=("Arial", 8, "bold"), padx=8, pady=3, relief="ridge", bd=1)
            status_badge.pack(anchor="center")

            tk.Label(card, text=tm, bg="#162232", fg="#e2e8f0", font=("Arial", 9),
                     width=cols[8][1] // 9, anchor="center").pack(side="left", padx=3)
            tk.Label(card, text=gmail, bg="#162232", fg="#38bdf8" if gmail != "—" else MUTED,
                     font=("Arial", 8), width=cols[9][1] // 9, anchor="center").pack(side="left", padx=3)

    def _chosen_date(self):
        try:
            month = list(calendar.month_name).index(self.cal_month.get())
            return date(int(self.cal_year.get()), month, int(self.cal_day.get()))
        except (ValueError, IndexError):
            messagebox.showerror("Invalid date", "Choose a valid month, year, and day.")
            return None

    def show_calendar(self):
        chosen = self._chosen_date()
        if not chosen:
            return
        self.selected_day = chosen
        self._clear_body()
        self.cal_controls.pack(fill="x", before=self.records_frame, pady=5)
        days_in_m = calendar.monthrange(chosen.year, chosen.month)[1]
        leap_label = "Leap Year (366 days)" if calendar.isleap(chosen.year) else "Normal Year (365 days)"
        self.info_label.config(
            text=f"Calendar View — {calendar.month_name[chosen.month]} {chosen.year} ({days_in_m} days | {leap_label}) | Click any date to view attendance"
        )

        students = sorted(load_registered_students(), key=usn_sort_key)
        start_month = date(chosen.year, chosen.month, 1)
        end_month = date(chosen.year, chosen.month, days_in_m)
        month_att = get_attendance_map(start_month, end_month)
        present = {(k[0], k[1], k[2]) for k in month_att}
        attendance_dates_set = get_attendance_dates()
        today = date.today()

        split = tk.Frame(self.records_frame, bg=BG)
        split.pack(fill="both", expand=True)
        split.grid_columnconfigure(0, weight=4, uniform="calendar_panes")
        split.grid_columnconfigure(1, weight=6, uniform="calendar_panes")
        split.grid_rowconfigure(0, weight=1)

        left = tk.Frame(split, bg="#122235", bd=1, relief="solid", highlightbackground="#31516b")
        right = tk.Frame(split, bg="#122235", bd=1, relief="solid", highlightbackground="#31516b")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 5), pady=2)
        right.grid(row=0, column=1, sticky="nsew", padx=(5, 0), pady=2)

        calendar_header = tk.Frame(left, bg="#122235")
        calendar_header.pack(fill="x", padx=10, pady=8)
        tk.Label(calendar_header, text=f"▦  Calendar View ({calendar.month_name[chosen.month]} {chosen.year})",
                 bg="#122235", fg="white", font=("Arial", 13, "bold")).pack(side="left", anchor="w")
        tk.Button(calendar_header, text="↻ Refresh", command=self.show_calendar,
                  bg="#0e7490", fg="white", activebackground="#0891b2",
                  relief="flat", padx=9, pady=5).pack(side="right", padx=(5, 0))

        nav = tk.Frame(left, bg="#122235")
        nav.pack(fill="x", padx=8, pady=(0, 6))

        def move_month(delta):
            idx = chosen.year * 12 + chosen.month - 1 + delta
            year, month0 = divmod(idx, 12)
            month = month0 + 1
            self.cal_year.set(year)
            self.cal_month.set(calendar.month_name[month])
            self.cal_day.set(min(self.cal_day.get(), calendar.monthrange(year, month)[1]))
            self.show_calendar()

        tk.Button(nav, text="‹", command=lambda: move_month(-1), bg="#24558b", fg="white",
                  relief="flat", width=3, font=("Arial", 12, "bold")).pack(side="left", padx=3)
        tk.Label(nav, text=f"{calendar.month_name[chosen.month]} {chosen.year}", bg="#122235", fg="white",
                 font=("Arial", 10, "bold")).pack(side="left", expand=True)
        tk.Button(nav, text="›", command=lambda: move_month(1), bg="#24558b", fg="white",
                  relief="flat", width=3, font=("Arial", 12, "bold")).pack(side="right", padx=3)

        cal_area = tk.Frame(left, bg="#122235")
        cal_area.pack(fill="both", expand=True, padx=7, pady=3)
        self.calendar_scroll_area = cal_area
        cal_canvas = tk.Canvas(cal_area, bg="#122235", highlightthickness=0)
        self.calendar_canvas = cal_canvas
        cal_vscroll = ttk.Scrollbar(cal_area, orient="vertical", command=cal_canvas.yview)
        cal_canvas.configure(yscrollcommand=cal_vscroll.set)
        cal_vscroll.pack(side="right", fill="y")
        cal_canvas.pack(side="left", fill="both", expand=True)

        grid = tk.Frame(cal_canvas, bg="#122235")
        cal_canvas.create_window((0, 0), window=grid, anchor="nw", tags="calendar_grid")
        grid.bind("<Configure>", lambda _e: cal_canvas.configure(scrollregion=cal_canvas.bbox("all")))

        for col, day_name in enumerate(("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")):
            tk.Label(grid, text=day_name, bg="#263c52", fg=("#fb7185" if day_name == "Sun" else "white"),
                     font=("Arial", 9, "bold"), padx=5, pady=7).grid(row=0, column=col, sticky="nsew", padx=1, pady=1)
            grid.grid_columnconfigure(col, weight=1, uniform="weekday")

        for row_idx, week in enumerate(calendar.Calendar(firstweekday=0).monthdayscalendar(chosen.year, chosen.month), 1):
            for col, day_num in enumerate(week):
                cell_bg = "#e2e8f0" if col == 6 else "#f8fafc"
                cell = tk.Frame(grid, bg=cell_bg, bd=1, relief="solid")
                cell.grid(row=row_idx, column=col, sticky="nsew", padx=1, pady=1)
                cell.configure(width=45, height=58)
                cell.grid_propagate(False)
                if not day_num:
                    continue
                d = date(chosen.year, chosen.month, day_num)
                is_selected = d == self.selected_day
                if is_selected:
                    cell_bg = "#0284c7"
                    cell.configure(bg=cell_bg)
                fg = "#7f1d1d" if d.weekday() == 6 and not is_selected else ("white" if is_selected else "#0f172a")
                tk.Button(cell, text=str(day_num), command=lambda picked=d: self._calendar_select_day(picked),
                          bg=cell_bg, fg=fg, activebackground="#38bdf8", relief="flat",
                          font=("Arial", 10, "bold"), bd=0).pack(fill="x", padx=2, pady=(2, 0))

                if d.weekday() == 6 and d != today:
                    tk.Label(cell, text="Holiday", bg=cell_bg, fg=("white" if is_selected else "#991b1b"),
                             font=("Arial", 7, "bold")).pack()
                elif d > today:
                    dot_row = tk.Frame(cell, bg=cell_bg)
                    dot_row.pack(pady=(1, 2))
                    tk.Label(dot_row, text="●", bg=cell_bg, fg="#94a3b8", font=("Arial", 8)).pack(side="left")
                    tk.Label(dot_row, text="—", bg=cell_bg, fg=("white" if is_selected else "#64748b"),
                             font=("Arial", 7)).pack(side="left")
                else:
                    day_present = sum((st[0].lower(), st[1].lower(), d.isoformat()) in present for st in students)
                    if day_present > 0:
                        dot_color, label = GREEN, f"{day_present}/{len(students)}"
                    elif d == today:
                        dot_color, label = "#38bdf8", "Today"
                    elif d.isoformat() in attendance_dates_set:
                        dot_color, label = RED, "0 present"
                    else:
                        dot_color, label = "#f9a8d4", "—"

                    dot_row = tk.Frame(cell, bg=cell_bg)
                    dot_row.pack(pady=(1, 2))
                    tk.Label(dot_row, text="●", bg=cell_bg, fg=dot_color, font=("Arial", 8)).pack(side="left")
                    tk.Label(dot_row, text=label, bg=cell_bg, fg=("white" if is_selected else "#334155"),
                             font=("Arial", 7)).pack(side="left")

        legend = tk.Frame(left, bg="#122235")
        legend.pack(fill="x", padx=8, pady=8)
        for color, label in ((GREEN, "Present"), (RED, "Absent"), ("#f9a8d4", "Not Recorded"), ("#e2e8f0", "Sunday Holiday")):
            tk.Label(legend, text="●", fg=color, bg="#122235", font=("Arial", 9, "bold")).pack(side="left", padx=(3, 1))
            tk.Label(legend, text=label, fg="white", bg="#122235", font=("Arial", 8)).pack(side="left", padx=(0, 5))

        self.calendar_detail_title = tk.Label(right, text="", bg="#122235", fg="white",
                                               font=("Arial", 12, "bold"), anchor="w")
        self.calendar_detail_title.pack(fill="x", padx=10, pady=10)
        self.calendar_table_holder = tk.Frame(right, bg="#122235")
        self.calendar_table_holder.pack(fill="both", expand=True, padx=7, pady=(0, 7))
        self._render_calendar_day(self.selected_day, students)

    def _calendar_select_day(self, chosen):
        self.selected_day = chosen
        self.cal_year.set(chosen.year)
        self.cal_month.set(calendar.month_name[chosen.month])
        self.cal_day.set(chosen.day)
        self.show_calendar()

    def _render_calendar_day(self, chosen, students=None):
        if students is None:
            students = sorted(load_registered_students(), key=usn_sort_key)
        for widget in self.calendar_table_holder.winfo_children():
            widget.destroy()

        today = date.today()
        if chosen.weekday() == 6 and chosen != today:
            self.calendar_detail_title.config(text=f"Attendance — {format_date(chosen.isoformat())} ({chosen.strftime('%A')}) — SUNDAY HOLIDAY")
        elif chosen > today:
            self.calendar_detail_title.config(text=f"Attendance — {format_date(chosen.isoformat())} ({chosen.strftime('%A')}) — UPCOMING / NOT RECORDED")
        elif chosen == today:
            self.calendar_detail_title.config(text=f"Attendance — {format_date(chosen.isoformat())} ({chosen.strftime('%A')}) — TODAY'S ATTENDANCE")
        else:
            self.calendar_detail_title.config(text=f"Attendance — {format_date(chosen.isoformat())} ({chosen.strftime('%A')})")

        headings = ("#", "Name", "USN", "Branch", "Sem", "Status", "Time", "Gmail")
        holder = self.calendar_table_holder
        tree_style = ttk.Style(self.window)
        tree_style.configure("Calendar.Treeview", rowheight=50, font=("Arial", 10))
        tree_style.configure("Calendar.Treeview.Heading", font=("Arial", 10, "bold"))
        tree = ttk.Treeview(holder, columns=headings, show="tree headings", selectmode="browse", style="Calendar.Treeview")
        self.calendar_tree = tree

        tree.heading("#0", text="Photo")
        tree.column("#0", width=66, minwidth=60, anchor="center", stretch=False)
        widths = {"#": 35, "Name": 135, "USN": 70, "Branch": 65, "Sem": 45, "Status": 95, "Time": 85, "Gmail": 150}
        for heading in headings:
            tree.heading(heading, text=heading)
            tree.column(heading, width=widths.get(heading, 85), minwidth=40, anchor="center", stretch=True)

        tree.tag_configure("PRESENT", background="#064e3b", foreground="white")
        tree.tag_configure("ABSENT", background="#7f1d1d", foreground="white")
        tree.tag_configure("HOLIDAY", background="#713f12", foreground="white")
        tree.tag_configure("NOT RECORDED", background="#334155", foreground="white")

        vs = ttk.Scrollbar(holder, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(holder, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set)

        self._calendar_photo_refs.clear()
        att = get_attendance_map(chosen)
        attendance_dates_set = get_attendance_dates()
        report_rows = []

        for index, student in enumerate(students, 1):
            status, time_value, photo_file = determine_status_and_time(
                student[0], student[1], chosen, att, attendance_dates_set
            )
            photo_path = photo_for_student(student[0], student[1], photo_file)
            s_email = student[4] if len(student) >= 5 else ""
            photo = None
            if photo_path and os.path.exists(photo_path):
                try:
                    im = Image.open(photo_path).convert("RGB")
                    im = ImageOps.fit(im, (42, 42), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
                    canvas = ImageOps.expand(im, border=2, fill="#38bdf8")
                    draw = ImageDraw.Draw(canvas)
                    draw.rectangle((2, 2, 43, 43), outline="#e2e8f0", width=1)
                    photo = ImageTk.PhotoImage(canvas)
                    self._calendar_photo_refs.append(photo)
                except Exception:
                    photo = None

            tree.insert("", "end", text="", image=photo,
                        values=(index, student[0], student[1], student[2], student[3], status, time_value, s_email or "—"),
                        tags=(status,))

            report_rows.append([student[0], student[1], student[2], student[3],
                                format_date(chosen.isoformat()), status, time_value, s_email])

        tree.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        holder.grid_rowconfigure(0, weight=1)
        holder.grid_columnconfigure(0, weight=1)

        self.last_report = (f"Attendance Report — {format_date(chosen.isoformat())}",
                            ["Name", "USN", "Branch", "Semester", "Date", "Status", "Time", "Gmail"],
                            report_rows)

    def show_day(self, chosen):
        self.entries["date"].delete(0, tk.END)
        self.entries["date"].insert(0, format_date(chosen.isoformat()))
        self.filter_var.set("Today")
        self.load_attendance()

    def show_selected_day(self):
        chosen = self._chosen_date()
        if chosen:
            self.show_day(chosen)

    def show_selected_week(self):
        chosen = self._chosen_date()
        if not chosen:
            return
        start = chosen - timedelta(days=chosen.weekday())
        end = start + timedelta(days=6)
        self.filter_var.set("This Week")
        self.entries["date"].delete(0, tk.END)
        self._clear_body()
        rows = []
        students = sorted([s for s in load_registered_students() if self._matches_filters(s)], key=usn_sort_key)
        attendance_dates_set = get_attendance_dates()
        att_map = get_attendance_map(start, end)

        for s in students:
            s_email = s[4] if len(s) >= 5 else ""
            d = start
            while d <= end:
                status, tm, _ = determine_status_and_time(s[0], s[1], d, att_map, attendance_dates_set)
                rows.append([s[0], s[1], s[2], s[3], format_date(d.isoformat()), status, tm, s_email])
                d += timedelta(days=1)

        self.info_label.config(text=f"Week: {format_date(start.isoformat())} – {format_date(end.isoformat())}")
        self.last_report = ("Weekly Attendance Report", ["Name", "USN", "Branch", "Semester", "Date", "Status", "Time", "Gmail"], rows)
        self._render_table(self.last_report[1], rows)

    def clear_search(self):
        for e in self.entries.values():
            e.delete(0, tk.END)
        self.filter_var.set("Today")
        self.load_attendance()

    # ------------------ INFORM ABSENTEES & ONCE-PER-DAY AUTO DISPATCH ------------------
    def open_email_center(self, on_close_callback):
        dialog = tk.Toplevel(self.window)
        dialog.title("Attendance & Absentee Email Center")
        dialog.configure(bg=BG)
        dialog.geometry("1280x810")
        dialog.minsize(980, 640)
        dialog.resizable(True, True)

        self._email_dialog_fullscreen = False

        def toggle_fullscreen():
            self._email_dialog_fullscreen = not self._email_dialog_fullscreen
            dialog.attributes("-fullscreen", self._email_dialog_fullscreen)

        dialog.bind("<F11>", lambda e: toggle_fullscreen())

        top_bar = tk.Frame(dialog, bg="#15283b")
        top_bar.pack(fill="x", padx=12, pady=10)
        tk.Label(top_bar, text="✉  ATTENDANCE & ABSENTEE EMAIL CENTER", bg="#15283b", fg="white",
                 font=("Arial", 16, "bold")).pack(side="left", padx=14, pady=12)

        tk.Button(top_bar, text="← Back to Main", command=lambda: (dialog.destroy(), on_close_callback()),
                  bg="#334155", fg="white", relief="flat", padx=12, pady=5, font=("Arial", 9, "bold")).pack(side="right", padx=(6, 14))
        tk.Button(top_bar, text="⛶ Fullscreen (F11)", command=toggle_fullscreen, bg="#0e7490", fg="white",
                  relief="flat", padx=10, pady=5, font=("Arial", 9, "bold")).pack(side="right", padx=6)

        today_iso = date.today().isoformat()
        auto_cnt, auto_time = get_today_auto_dispatch_summary(today_iso)
        if auto_cnt > 0 and auto_time:
            banner = tk.Frame(dialog, bg="#064e3b", bd=1, relief="ridge")
            banner.pack(fill="x", padx=14, pady=(0, 6))
            tk.Label(
                banner,
                text=f"✓ AUTOMATIC DISPATCH COMPLETED TODAY: Absentee alerts were automatically sent to {auto_cnt} absent student(s) at {auto_time} (duplicate sends are locked).",
                bg="#064e3b", fg="#6ee7b7", font=("Arial", 9, "bold"), pady=6
            ).pack()
            dialog.after(300, lambda: messagebox.showinfo(
                "Automatic Absentee Dispatch Status",
                f"Absentee emails have already been sent automatically today at {auto_time} ({auto_cnt} student(s) notified).\n\n"
                "Each absent student receives this notice only once per day. You can still manually send Progress Reports & PDFs.",
                parent=dialog
            ))

        settings_frame = tk.Frame(dialog, bg="#17263a", bd=1, relief="ridge")
        settings_frame.pack(fill="x", padx=14, pady=(0, 8), ipady=4)

        r1 = tk.Frame(settings_frame, bg="#17263a")
        r1.pack(fill="x", padx=8, pady=4)

        tk.Label(r1, text="Period Scope:", bg="#17263a", fg="white", font=("Arial", 10, "bold")).pack(side="left", padx=4)
        period_var = tk.StringVar(value="Today")
        period_combo = ttk.Combobox(r1, textvariable=period_var, state="readonly", width=14,
                                    values=["Today", "This Week", "This Month", "This Year"])
        period_combo.pack(side="left", padx=4)

        tk.Label(r1, text="Filter Status:", bg="#17263a", fg="white", font=("Arial", 10, "bold")).pack(side="left", padx=(14, 4))
        status_filter_var = tk.StringVar(value="All Students")
        status_combo = ttk.Combobox(r1, textvariable=status_filter_var, state="readonly", width=15,
                                    values=["All Students", "Only Absentees", "Only Present"])
        status_combo.pack(side="left", padx=4)

        saved_time_str = get_meta("auto_dispatch_time", "11:30 AM")
        try:
            parsed_t = datetime.strptime(saved_time_str.strip(), "%I:%M %p")
            def_hh = parsed_t.strftime("%I")
            def_mm = parsed_t.strftime("%M")
            def_ampm = parsed_t.strftime("%p")
        except Exception:
            def_hh, def_mm, def_ampm = "11", "30", "AM"

        auto_dispatch_var = tk.BooleanVar(value=(get_meta("auto_dispatch_enabled", "1") == "1"))
        chk_auto = tk.Checkbutton(r1, text="Auto Absent Dispatch at:", variable=auto_dispatch_var,
                                  bg="#17263a", fg="#38bdf8", selectcolor=PANEL, activebackground="#17263a", activeforeground="white",
                                  font=("Arial", 9, "bold"))
        chk_auto.pack(side="left", padx=(18, 4))

        hh_var = tk.StringVar(value=def_hh)
        hh_combo = ttk.Combobox(r1, textvariable=hh_var, values=[f"{i:02d}" for i in range(1, 13)], width=3, state="readonly")
        hh_combo.pack(side="left", padx=1)

        tk.Label(r1, text=":", bg="#17263a", fg="white", font=("Arial", 10, "bold")).pack(side="left")

        mm_var = tk.StringVar(value=def_mm)
        mm_combo = ttk.Combobox(r1, textvariable=mm_var, values=[f"{i:02d}" for i in range(0, 60, 5)], width=3, state="readonly")
        mm_combo.pack(side="left", padx=1)

        ampm_var = tk.StringVar(value=def_ampm)
        ampm_combo = ttk.Combobox(r1, textvariable=ampm_var, values=["AM", "PM"], width=4, state="readonly")
        ampm_combo.pack(side="left", padx=3)

        scope_summary_lbl = tk.Label(r1, text="", bg="#17263a", fg="#fbbf24", font=("Arial", 9, "bold"))
        scope_summary_lbl.pack(side="right", padx=10)

        r2 = tk.Frame(settings_frame, bg="#17263a")
        r2.pack(fill="x", padx=8, pady=4)

        tk.Label(r2, text="Sender Admin Gmail:", bg="#17263a", fg="#cbd5e1", font=("Arial", 9, "bold")).pack(side="left", padx=4)
        admin_entry = tk.Entry(r2, width=30, font=("Arial", 9))
        admin_entry.insert(0, get_meta("sender_email", "sniyamath661@gmail.com"))
        admin_entry.pack(side="left", padx=4)
        bind_clipboard_menu(admin_entry)

        tk.Label(r2, text="Gmail App Password:", bg="#17263a", fg="#cbd5e1", font=("Arial", 9, "bold")).pack(side="left", padx=(14, 4))
        pwd_entry = tk.Entry(r2, width=22, show="*", font=("Arial", 9))
        pwd_entry.insert(0, get_meta("sender_password", ""))
        pwd_entry.pack(side="left", padx=4)
        bind_clipboard_menu(pwd_entry)

        def save_email_settings_action():
            new_email = admin_entry.get().strip()
            new_pwd = pwd_entry.get().strip()
            time_val = f"{hh_var.get().strip()}:{mm_var.get().strip()} {ampm_var.get().strip()}"
            is_enabled = "1" if auto_dispatch_var.get() else "0"

            if not new_email:
                messagebox.showerror("Error", "Sender Gmail cannot be empty.", parent=dialog)
                return

            set_meta("sender_email", new_email)
            set_meta("sender_password", new_pwd)
            set_meta("auto_dispatch_time", time_val)
            set_meta("auto_dispatch_enabled", is_enabled)

            self.sender_email = new_email
            self.sender_pwd = new_pwd
            self.auto_absent_enabled = (is_enabled == "1")

            try:
                parsed_time = datetime.strptime(time_val, "%I:%M %p")
                self.auto_hour_24 = parsed_time.hour
                self.auto_min = parsed_time.minute
            except Exception:
                pass

            register_windows_background_task(time_val, enabled=(is_enabled == "1"))

            self.admin_footer_lbl.config(
                text=f"Working days: Mon–Sat\nSunday: Holiday\nSender: {self.sender_email}"
            )
            messagebox.showinfo(
                "Saved & Scheduled",
                f"Settings saved!\n\nSender: {new_email}\nAuto-Absent Dispatch: {time_val} ({'Enabled' if is_enabled == '1' else 'Disabled'})\n"
                "Background task registered to fire automatically even if the application is closed.",
                parent=dialog
            )

        tk.Button(r2, text="💾 Save Settings", command=save_email_settings_action,
                  bg="#059669", fg="white", activebackground="#10b981", font=("Arial", 9, "bold"),
                  relief="flat", padx=12, pady=3).pack(side="left", padx=14)

        hdr_bar = tk.Frame(dialog, bg="#15283b", bd=1, relief="solid", highlightbackground="#31516b")
        hdr_bar.pack(fill="x", padx=14, pady=(6, 4))
        cols_spec = [("Select", 55), ("Photo", 65), ("#", 35), ("USN", 95), ("Student Name", 165),
                     ("Branch", 75), ("Sem", 50), ("Status", 95), ("Attended", 115), ("Attendance %", 100), ("Registered Gmail", 190)]
        for cname, cwidth in cols_spec:
            tk.Label(hdr_bar, text=cname, bg="#15283b", fg="white", font=("Arial", 9, "bold"),
                     width=cwidth // 9, anchor="center").pack(side="left", padx=2, pady=5)

        cards_container = tk.Frame(dialog, bg=BG)
        cards_container.pack(fill="both", expand=True, padx=14, pady=4)

        canvas = tk.Canvas(cards_container, bg=BG, highlightthickness=0)
        self.email_scroll_canvas = canvas
        vs = ttk.Scrollbar(cards_container, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vs.set)
        vs.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        card_list_frame = tk.Frame(canvas, bg=BG)
        win_id = canvas.create_window((0, 0), window=card_list_frame, anchor="nw")

        def _on_config(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(win_id, width=canvas.winfo_width())

        card_list_frame.bind("<Configure>", _on_config)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win_id, width=e.width))

        student_data_map = {}
        student_checkbox_vars = {}
        self._email_card_photos = []

        def get_date_bounds():
            today = date.today()
            sel = period_var.get()
            if sel == "Today":
                return today, today
            elif sel == "This Week":
                s = today - timedelta(days=today.weekday())
                return s, s + timedelta(days=6)
            elif sel == "This Month":
                days_in_month = calendar.monthrange(today.year, today.month)[1]
                return date(today.year, today.month, 1), date(today.year, today.month, days_in_month)
            else:
                return date(today.year, 1, 1), date(today.year, 12, 31)

        def refresh_email_cards():
            for w in card_list_frame.winfo_children():
                w.destroy()
            student_data_map.clear()
            student_checkbox_vars.clear()
            self._email_card_photos.clear()

            start_d, end_d = get_date_bounds()
            att_map = get_attendance_map(start_d, end_d)
            attendance_dates_set = get_attendance_dates()
            students = sorted(load_registered_students(), key=usn_sort_key)
            st_filter = status_filter_var.get()
            today = date.today()

            total_cal_days = (end_d - start_d).days + 1
            sample_holidays = sum(
                1 for offset in range(total_cal_days)
                if (start_d + timedelta(days=offset)).weekday() == 6 and (start_d + timedelta(days=offset)) != today
            )
            sample_working = total_cal_days - sample_holidays
            leap_note = f" ({'Leap' if calendar.isleap(today.year) else 'Normal'} Year)" if period_var.get() == "This Year" else ""
            scope_summary_lbl.config(
                text=f"Total: {total_cal_days}d{leap_note} | Working: {sample_working}d | Holidays: {sample_holidays}d"
            )

            for idx, s in enumerate(students, 1):
                name, usn, branch, sem, email = s[0], s[1], s[2], s[3], s[4]
                present_cnt, absent_cnt, holiday_cnt, total_working_days = 0, 0, 0, 0
                log_rows = []

                cur_d = start_d
                while cur_d <= end_d:
                    cur_iso = cur_d.isoformat()
                    is_sunday = (cur_d.weekday() == 6)
                    st, tm, _ = determine_status_and_time(name, usn, cur_d, att_map, attendance_dates_set)

                    if is_sunday and cur_d != today and st != "PRESENT":
                        holiday_cnt += 1
                    else:
                        total_working_days += 1
                        if st == "PRESENT":
                            present_cnt += 1
                            log_rows.append((format_date(cur_iso), "PRESENT", tm))
                        else:
                            absent_cnt += 1
                            if cur_d <= today:
                                log_rows.append((format_date(cur_iso), st, "-"))
                    cur_d += timedelta(days=1)

                pct = (present_cnt / total_working_days * 100) if total_working_days > 0 else 0.0

                if period_var.get() == "Today":
                    summary_status = "PRESENT" if present_cnt > 0 else "ABSENT"
                else:
                    summary_status = "REGULAR" if pct >= 75 else ("WARNING" if pct >= 60 else "CRITICAL")

                if st_filter == "Only Absentees" and present_cnt > 0 and absent_cnt == 0:
                    continue
                if st_filter == "Only Present" and present_cnt == 0:
                    continue

                if summary_status == "PRESENT":
                    border_color, card_bg, badge_bg, badge_fg, status_text = BLUE, "#112233", "#0369a1", "white", "PRESENT"
                elif summary_status == "ABSENT":
                    border_color, card_bg, badge_bg, badge_fg, status_text = RED, "#271216", "#b91c1c", "white", "ABSENT"
                else:
                    border_color, card_bg, badge_bg, badge_fg, status_text = COFFEE, COFFEE_BG, "#78350f", "#fef08a", "NOT RECORDED"

                sent_log = has_absent_email_been_sent(usn, today.isoformat())
                gmail_display = email if email else "No Gmail Set"
                if sent_log:
                    gmail_display += f"  [Sent {sent_log[0]}]"

                card = tk.Frame(card_list_frame, bg=card_bg, bd=1, relief="solid",
                                highlightbackground=border_color, highlightthickness=1.5)
                card.pack(fill="x", padx=4, pady=4)

                var_check = tk.BooleanVar(value=False)
                student_checkbox_vars[usn] = var_check
                cb = tk.Checkbutton(card, variable=var_check, bg=card_bg, selectcolor=PANEL, activebackground=card_bg)
                cb.pack(side="left", padx=(10, 2))

                photo_frame = tk.Frame(card, bg=card_bg, width=65, height=52)
                photo_frame.pack(side="left", padx=3, pady=4)
                photo_frame.pack_propagate(False)

                photo_path = photo_for_student(name, usn)
                thumb = None
                if photo_path and os.path.exists(photo_path):
                    try:
                        im = Image.open(photo_path).convert("RGB")
                        im = ImageOps.fit(im, (38, 38), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
                        canvas_img = ImageOps.expand(im, border=2, fill=border_color)
                        draw = ImageDraw.Draw(canvas_img)
                        draw.rectangle((2, 2, 39, 39), outline="#e2e8f0", width=1)
                        thumb = ImageTk.PhotoImage(canvas_img)
                        self._email_card_photos.append(thumb)
                    except Exception:
                        thumb = None

                if thumb:
                    tk.Label(photo_frame, image=thumb, bg=card_bg).pack(expand=True)
                else:
                    tk.Label(photo_frame, text="No Pic", bg="#20364d", fg=MUTED, font=("Arial", 7), relief="solid", bd=1).pack(expand=True)

                tk.Label(card, text=str(idx), bg=card_bg, fg=MUTED, font=("Arial", 9, "bold"),
                         width=cols_spec[2][1] // 9, anchor="center").pack(side="left", padx=2)
                tk.Label(card, text=usn, bg=card_bg, fg="#38bdf8", font=("Arial", 9, "bold"),
                         width=cols_spec[3][1] // 9, anchor="center").pack(side="left", padx=2)
                tk.Label(card, text=name, bg=card_bg, fg="white", font=("Arial", 9, "bold"),
                         width=cols_spec[4][1] // 9, anchor="w").pack(side="left", padx=2)
                tk.Label(card, text=branch, bg=card_bg, fg="white", font=("Arial", 9),
                         width=cols_spec[5][1] // 9, anchor="center").pack(side="left", padx=2)
                tk.Label(card, text=sem, bg=card_bg, fg="white", font=("Arial", 9),
                         width=cols_spec[6][1] // 9, anchor="center").pack(side="left", padx=2)

                badge_box = tk.Frame(card, bg=card_bg, width=cols_spec[7][1])
                badge_box.pack(side="left", padx=2)
                tk.Label(badge_box, text=status_text, bg=badge_bg, fg=badge_fg,
                         font=("Arial", 8, "bold"), padx=8, pady=2, relief="ridge", bd=1).pack(anchor="center")

                tk.Label(card, text=f"{present_cnt}/{total_working_days} d", bg=card_bg, fg="#cbd5e1", font=("Arial", 9),
                         width=cols_spec[8][1] // 9, anchor="center").pack(side="left", padx=2)
                tk.Label(card, text=f"{pct:.1f}%", bg=card_bg, fg=GREEN if pct >= 75 else (RED if pct < 60 else "#f59e0b"),
                         font=("Arial", 9, "bold"), width=cols_spec[9][1] // 9, anchor="center").pack(side="left", padx=2)
                tk.Label(card, text=gmail_display, bg=card_bg, fg="#38bdf8" if email else MUTED,
                         font=("Arial", 8), width=cols_spec[10][1] // 9, anchor="w").pack(side="left", padx=4)

                student_data_map[usn] = {
                    "name": name, "usn": usn, "branch": branch, "sem": sem, "email": email,
                    "present_cnt": present_cnt, "total_working": total_working_days, "absent_cnt": absent_cnt,
                    "holiday_cnt": holiday_cnt, "pct": pct, "log_rows": log_rows, "period": period_var.get(),
                    "photo_path": photo_path,
                    "date_str": f"{format_date(start_d.isoformat())} to {format_date(end_d.isoformat())}" if start_d != end_d else format_date(start_d.isoformat())
                }

        period_combo.bind("<<ComboboxSelected>>", lambda e: refresh_email_cards())
        status_combo.bind("<<ComboboxSelected>>", lambda e: refresh_email_cards())
        refresh_email_cards()

        sel_row = tk.Frame(dialog, bg=BG)
        sel_row.pack(fill="x", padx=14, pady=2)

        def toggle_all_checks():
            val = select_all_var.get()
            for v in student_checkbox_vars.values():
                v.set(val)

        select_all_var = tk.BooleanVar(value=False)
        tk.Checkbutton(sel_row, text="✓ Select All / Deselect All", variable=select_all_var,
                       command=toggle_all_checks, bg=BG, fg="white", selectcolor=PANEL,
                       activebackground=BG, activeforeground="white", font=("Arial", 9, "bold")).pack(side="left")

        action_box = tk.Frame(dialog, bg="#111e2d", bd=1, relief="ridge")
        action_box.pack(fill="x", padx=14, pady=8)

        left_col = tk.Frame(action_box, bg="#111e2d")
        left_col.pack(side="left", fill="both", expand=True, padx=12, pady=10)
        tk.Label(left_col, text="COLUMN 1: ABSENTEE ALERTS (ONCE PER DAY)", bg="#111e2d", fg="#ef4444",
                 font=("Arial", 11, "bold")).pack(anchor="w")
        tk.Label(left_col, text="Sends absence notice once per day per student (prevents duplicate alerts).",
                 bg="#111e2d", fg=MUTED, font=("Arial", 8)).pack(anchor="w", pady=(0, 6))

        right_col = tk.Frame(action_box, bg="#111e2d")
        right_col.pack(side="right", fill="both", expand=True, padx=12, pady=10)
        tk.Label(right_col, text="COLUMN 2: FULL ATTENDANCE REPORT & GRAPH", bg="#111e2d", fg="#38bdf8",
                 font=("Arial", 11, "bold")).pack(anchor="w")
        tk.Label(right_col, text="Sends calendar-accurate % (6-day week / 28-31 day month / 365-366 day year) + chart & PDF.",
                 bg="#111e2d", fg=MUTED, font=("Arial", 8)).pack(anchor="w", pady=(0, 6))

        def dispatch_worker(mode, sender, pwd, selected_usns):
            sent_count, skipped_no_email, already_sent_count = 0, 0, 0
            already_sent_details = []
            errors = []
            today_str = date.today().isoformat()

            try:
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
                    server.login(sender, pwd)
                    for usn in selected_usns:
                        st_info = student_data_map.get(usn)
                        if not st_info:
                            continue
                        recipient = st_info["email"]
                        if not recipient or "@" not in recipient:
                            skipped_no_email += 1
                            continue

                        if mode == "ABSENT":
                            prior = has_absent_email_been_sent(usn, today_str)
                            if prior is not None:
                                already_sent_count += 1
                                already_sent_details.append(f"• {st_info['name']} (already sent at {prior[0]})")
                                continue

                        msg_root = MIMEMultipart("related")
                        msg_root["From"] = f"Face Attendance System <{sender}>"
                        msg_root["To"] = recipient

                        msg_alt = MIMEMultipart("alternative")
                        msg_root.attach(msg_alt)

                        has_photo = bool(st_info["photo_path"] and os.path.exists(st_info["photo_path"]))

                        if mode == "ABSENT":
                            msg_root["Subject"] = f"Attendance Notice: {st_info['name']} was marked ABSENT ({st_info['date_str']})"
                            html = generate_absent_email_html(
                                sender, st_info['name'], st_info['usn'], st_info['branch'], st_info['sem'],
                                st_info['date_str'], has_photo=has_photo
                            )
                        else:
                            msg_root["Subject"] = f"Attendance Progress Report: {st_info['name']} ({st_info['pct']:.1f}% - {st_info['period']})"
                            html = generate_attendance_report_email_html(
                                sender, st_info['name'], st_info['usn'], st_info['branch'], st_info['sem'],
                                st_info['period'], st_info['present_cnt'], st_info['total_working'],
                                st_info['absent_cnt'], st_info['holiday_cnt'], st_info['pct'],
                                st_info['log_rows'], has_photo=has_photo
                            )

                        msg_alt.attach(MIMEText(html, "html"))

                        if has_photo:
                            try:
                                with open(st_info["photo_path"], "rb") as f_img:
                                    mime_photo = MIMEImage(f_img.read())
                                    mime_photo.add_header('Content-ID', '<student_photo>')
                                    mime_photo.add_header('Content-Disposition', 'inline')
                                    msg_root.attach(mime_photo)
                            except Exception:
                                pass

                        if mode != "ABSENT":
                            chart_bytes = generate_attendance_chart_bytes(st_info['present_cnt'], st_info['absent_cnt'], st_info['holiday_cnt'])
                            if chart_bytes:
                                mime_chart = MIMEImage(chart_bytes)
                                mime_chart.add_header('Content-ID', '<attendance_chart>')
                                mime_chart.add_header('Content-Disposition', 'inline', filename='attendance_graph.png')
                                msg_root.attach(mime_chart)

                            try:
                                pdf_data = generate_pdf_report_bytes(
                                    st_info['name'], st_info['usn'], st_info['branch'], st_info['sem'],
                                    st_info['period'], st_info['present_cnt'], st_info['total_working'],
                                    st_info['absent_cnt'], st_info['holiday_cnt'], st_info['pct'],
                                    st_info['log_rows']
                                )
                                if pdf_data:
                                    pdf_attachment = MIMEApplication(pdf_data, _subtype="pdf")
                                    pdf_attachment.add_header('Content-Disposition', 'attachment',
                                                              filename=f"Attendance_Report_{st_info['usn']}.pdf")
                                    msg_root.attach(pdf_attachment)
                            except Exception as pdf_err:
                                print(f"PDF creation warning for {st_info['name']}:", pdf_err)

                        try:
                            server.sendmail(sender, recipient, msg_root.as_string())
                            sent_count += 1
                            if mode == "ABSENT":
                                log_absent_email_sent(usn, today_str, mode="MANUAL")
                        except Exception as e:
                            errors.append(f"{st_info['name']}: {e}")

                summary_text = f"Dispatch Summary:\n\n• Newly Sent: {sent_count}\n• Skipped (No Gmail): {skipped_no_email}"
                if already_sent_count > 0:
                    summary_text += f"\n• Blocked Duplicate Alerts ({already_sent_count}):\n" + "\n".join(already_sent_details[:5])
                if errors:
                    summary_text += f"\n\nErrors ({len(errors)}):\n" + "\n".join(errors[:3])

                def finish_ui():
                    if dialog.winfo_exists():
                        refresh_email_cards()
                        messagebox.showinfo("Email Results", summary_text, parent=dialog)

                self.window.after(0, finish_ui)
            except Exception as exc:
                self.window.after(0, lambda: messagebox.showerror("SMTP Error", f"Failed to connect or authenticate with Gmail:\n{exc}", parent=dialog))

        def start_dispatch(mode="ABSENT"):
            sender = admin_entry.get().strip()
            pwd = pwd_entry.get().strip()
            if not sender or not pwd:
                messagebox.showerror("Credentials Required", "Please enter Sender Gmail and Gmail App Password.", parent=dialog)
                return

            selected_usns = [u for u, v in student_checkbox_vars.items() if v.get()]
            if not selected_usns:
                messagebox.showwarning("No Students Selected", "Please select at least one student.", parent=dialog)
                return

            threading.Thread(target=dispatch_worker, args=(mode, sender, pwd, selected_usns), daemon=True).start()
            messagebox.showinfo("Dispatch Started", "Sending routine running in background.", parent=dialog)

        tk.Button(left_col, text="✉ Send Absent Information", command=lambda: start_dispatch("ABSENT"),
                  bg="#dc2626", fg="white", activebackground="#b91c1c", font=("Arial", 9, "bold"),
                  relief="flat", padx=12, pady=7).pack(anchor="w")

        tk.Button(right_col, text="📊 Send Report + Percentage Graph & PDF", command=lambda: start_dispatch("REPORT"),
                  bg="#0284c7", fg="white", activebackground="#0369a1", font=("Arial", 9, "bold"),
                  relief="flat", padx=12, pady=7).pack(anchor="w")

        return dialog

    # ------------------ CHANGE INFO LOGIN & PANEL (CHANGE + PERMANENT DELETE) ------------------
    def open_change_info_login(self, on_close_callback):
        login_win = tk.Toplevel(self.window)
        login_win.title("Admin Authentication")
        login_win.configure(bg=BG)
        login_win.geometry("560x360")
        login_win.minsize(440, 300)
        login_win.resizable(True, True)

        self._login_fullscreen = False

        def toggle_fullscreen():
            self._login_fullscreen = not self._login_fullscreen
            login_win.attributes("-fullscreen", self._login_fullscreen)

        login_win.bind("<F11>", lambda e: toggle_fullscreen())

        top_bar = tk.Frame(login_win, bg="#15283b")
        top_bar.pack(fill="x", padx=12, pady=10)
        tk.Label(top_bar, text="🔒 ADMIN ACCESS REQUIRED", bg="#15283b", fg="white",
                 font=("Arial", 13, "bold")).pack(side="left", padx=12, pady=8)
        tk.Button(top_bar, text="⛶ Fullscreen (F11)", command=toggle_fullscreen, bg="#0e7490", fg="white",
                  relief="flat", padx=8, pady=4, font=("Arial", 8, "bold")).pack(side="right", padx=10)

        tk.Label(login_win, text="Enter credentials and press Enter to move down / login.",
                 bg=BG, fg=MUTED, font=("Arial", 9)).pack(pady=(6, 12))

        form = tk.Frame(login_win, bg=BG)
        form.pack(fill="x", padx=45)
        form.grid_columnconfigure(1, weight=1)

        tk.Label(form, text="Username:", bg=BG, fg="white", font=("Arial", 11, "bold")).grid(row=0, column=0, sticky="w", pady=8)
        user_ent = tk.Entry(form, font=("Arial", 11))
        user_ent.grid(row=0, column=1, sticky="ew", pady=8, padx=(12, 0), ipady=4)
        bind_clipboard_menu(user_ent)
        user_ent.focus_set()

        tk.Label(form, text="Password:", bg=BG, fg="white", font=("Arial", 11, "bold")).grid(row=1, column=0, sticky="w", pady=8)
        pass_ent = tk.Entry(form, show="*", font=("Arial", 11))
        pass_ent.grid(row=1, column=1, sticky="ew", pady=8, padx=(12, 0), ipady=4)
        bind_clipboard_menu(pass_ent)

        def verify_login(event=None):
            u = user_ent.get().strip()
            p = pass_ent.get().strip()
            if u == DEFAULT_ADMIN_USER and p == DEFAULT_ADMIN_PASS:
                login_win.destroy()
                self._open_exclusive_page(self.open_change_student_info_dashboard)
            else:
                messagebox.showerror("Access Denied", "Incorrect username or password!", parent=login_win)
                pass_ent.delete(0, tk.END)
                pass_ent.focus_set()

        user_ent.bind("<Return>", lambda e: (pass_ent.focus_set(), "break")[1])
        pass_ent.bind("<Return>", lambda e: (verify_login(), "break")[1])

        btn_box = tk.Frame(login_win, bg=BG)
        btn_box.pack(fill="x", padx=45, pady=(20, 10))
        tk.Button(btn_box, text="← Back to Main", command=lambda: (login_win.destroy(), on_close_callback()),
                  bg="#334155", fg="white", relief="flat", padx=14, pady=6).pack(side="right", padx=(6, 0))
        tk.Button(btn_box, text="Login", command=verify_login, bg=BLUE, fg="white",
                  font=("Arial", 10, "bold"), relief="flat", padx=18, pady=6).pack(side="right")
        return login_win

    def open_change_student_info_dashboard(self, on_close_callback):
        dash = tk.Toplevel(self.window)
        dash.title("Student Information Modification Panel")
        dash.configure(bg=BG)
        dash.geometry("1260x760")
        dash.minsize(960, 580)
        dash.resizable(True, True)

        self._dash_fullscreen = False

        def toggle_fullscreen():
            self._dash_fullscreen = not self._dash_fullscreen
            dash.attributes("-fullscreen", self._dash_fullscreen)

        dash.bind("<F11>", lambda e: toggle_fullscreen())

        top = tk.Frame(dash, bg="#15283b")
        top.pack(fill="x", padx=12, pady=10)
        tk.Label(top, text="⚙  CHANGE STUDENT INFORMATION PANEL", bg="#15283b", fg="white",
                 font=("Arial", 15, "bold")).pack(side="left", padx=14, pady=12)

        tk.Button(top, text="← Back to Main", command=lambda: (dash.destroy(), on_close_callback()),
                  bg="#334155", fg="white", relief="flat", padx=12, pady=5, font=("Arial", 9, "bold")).pack(side="right", padx=(6, 14))
        tk.Button(top, text="⛶ Fullscreen (F11)", command=toggle_fullscreen, bg="#0e7490", fg="white",
                  relief="flat", padx=10, pady=5, font=("Arial", 9, "bold")).pack(side="right", padx=6)

        hdr_bar = tk.Frame(dash, bg="#15283b", bd=1, relief="solid", highlightbackground="#31516b")
        hdr_bar.pack(fill="x", padx=14, pady=(4, 4))

        col_weights = [
            ("Photo", 0, 75),
            ("#", 0, 40),
            ("USN", 2, 105),
            ("Student Name", 3, 165),
            ("Branch", 2, 95),
            ("Sem", 1, 55),
            ("Registered Gmail", 4, 210),
            ("Actions", 2, 185)
        ]

        for col_idx, (cname, weight, min_w) in enumerate(col_weights):
            hdr_bar.grid_columnconfigure(col_idx, weight=weight, minsize=min_w)
            tk.Label(hdr_bar, text=cname, bg="#15283b", fg="white", font=("Arial", 9, "bold")
                     ).grid(row=0, column=col_idx, sticky="ew", padx=3, pady=6)

        container = tk.Frame(dash, bg=BG)
        container.pack(fill="both", expand=True, padx=14, pady=4)

        canvas = tk.Canvas(container, bg=BG, highlightthickness=0)
        self.change_scroll_canvas = canvas
        vs = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vs.set)
        vs.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        list_frame = tk.Frame(canvas, bg=BG)
        win_id = canvas.create_window((0, 0), window=list_frame, anchor="nw")

        def _on_config(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(win_id, width=canvas.winfo_width())

        list_frame.bind("<Configure>", _on_config)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win_id, width=e.width))

        self._change_card_photos = []

        def permanently_delete_student(student_tuple):
            st_name, st_usn, st_branch, st_sem, _ = student_tuple
            confirm = messagebox.askyesno(
                "Confirm Permanent Deletion",
                f"Are you sure you want to PERMANENTLY delete this student?\n\n"
                f"• Name: {st_name}\n"
                f"• USN: {st_usn}\n"
                f"• Branch / Sem: {st_branch} - {st_sem}\n\n"
                "WARNING: This will permanently delete their registration, all attendance records, "
                "email records, and face dataset images from the project. This cannot be undone!",
                icon="warning",
                parent=dash
            )
            if not confirm:
                return

            try:
                # 1. Remove from students.csv
                if os.path.exists("students.csv"):
                    kept_rows = []
                    with open("students.csv", "r", newline="", encoding="utf-8-sig") as f:
                        for row in csv.reader(f):
                            if len(row) >= 2 and row[1].strip().lower() == st_usn.lower():
                                continue
                            kept_rows.append(row)
                    with open("students.csv", "w", newline="", encoding="utf-8-sig") as f:
                        writer = csv.writer(f)
                        writer.writerows(kept_rows)

                # 2. Remove from SQLite database tables
                conn = db_connect()
                conn.execute("DELETE FROM attendance WHERE LOWER(usn)=LOWER(?)", (st_usn,))
                conn.execute("DELETE FROM student_emails WHERE LOWER(usn)=LOWER(?)", (st_usn,))
                conn.execute("DELETE FROM absent_email_log WHERE LOWER(usn)=LOWER(?)", (st_usn,))
                conn.commit()
                conn.close()

                # 3. Permanently delete face dataset folder
                dataset_folder = os.path.join("dataset", f"{st_name.strip().replace(' ', '_')}_{st_usn.strip()}")
                if os.path.isdir(dataset_folder):
                    shutil.rmtree(dataset_folder, ignore_errors=True)

                messagebox.showinfo(
                    "Deleted Permanently",
                    f"Student '{st_name}' ({st_usn}) has been permanently deleted from the project.",
                    parent=dash
                )
                render_student_cards()
            except Exception as exc:
                messagebox.showerror("Delete Error", f"Failed to completely delete student:\n{exc}", parent=dash)

        def render_student_cards():
            for w in list_frame.winfo_children():
                w.destroy()
            self._change_card_photos.clear()
            students = sorted(load_registered_students(), key=usn_sort_key)

            if not students:
                tk.Label(list_frame, text="No registered students found.", bg=BG, fg=MUTED,
                         font=("Arial", 12)).pack(pady=30)
                return

            for idx, s in enumerate(students, 1):
                name, usn, branch, sem, email = s[0], s[1], s[2], s[3], s[4]

                card = tk.Frame(list_frame, bg="#162232", bd=1, relief="solid",
                                highlightbackground="#31516b", highlightthickness=1)
                card.pack(fill="x", padx=4, pady=4)

                for col_idx, (_, weight, min_w) in enumerate(col_weights):
                    card.grid_columnconfigure(col_idx, weight=weight, minsize=min_w)

                photo_frame = tk.Frame(card, bg="#162232", width=65, height=52)
                photo_frame.grid(row=0, column=0, padx=3, pady=4)
                photo_frame.pack_propagate(False)

                photo_path = photo_for_student(name, usn)
                thumb = None
                if photo_path and os.path.exists(photo_path):
                    try:
                        im = Image.open(photo_path).convert("RGB")
                        im = ImageOps.fit(im, (38, 38), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
                        canvas_img = ImageOps.expand(im, border=2, fill="#38bdf8")
                        draw = ImageDraw.Draw(canvas_img)
                        draw.rectangle((2, 2, 39, 39), outline="#e2e8f0", width=1)
                        thumb = ImageTk.PhotoImage(canvas_img)
                        self._change_card_photos.append(thumb)
                    except Exception:
                        thumb = None

                if thumb:
                    tk.Label(photo_frame, image=thumb, bg="#162232").pack(expand=True)
                else:
                    tk.Label(photo_frame, text="No Pic", bg="#20364d", fg=MUTED, font=("Arial", 7), relief="solid", bd=1).pack(expand=True)

                tk.Label(card, text=str(idx), bg="#162232", fg=MUTED, font=("Arial", 9, "bold")
                         ).grid(row=0, column=1, sticky="ew", padx=2)
                tk.Label(card, text=usn, bg="#162232", fg="#38bdf8", font=("Arial", 9, "bold")
                         ).grid(row=0, column=2, sticky="ew", padx=2)
                tk.Label(card, text=name, bg="#162232", fg="white", font=("Arial", 9, "bold"), anchor="w"
                         ).grid(row=0, column=3, sticky="ew", padx=4)
                tk.Label(card, text=branch, bg="#162232", fg="white", font=("Arial", 9)
                         ).grid(row=0, column=4, sticky="ew", padx=2)
                tk.Label(card, text=sem, bg="#162232", fg="white", font=("Arial", 9)
                         ).grid(row=0, column=5, sticky="ew", padx=2)
                tk.Label(card, text=email or "No Gmail Set", bg="#162232", fg="#38bdf8" if email else MUTED, font=("Arial", 8), anchor="w"
                         ).grid(row=0, column=6, sticky="ew", padx=4)

                action_box = tk.Frame(card, bg="#162232")
                action_box.grid(row=0, column=7, sticky="ew", padx=4)
                btn_inner = tk.Frame(action_box, bg="#162232")
                btn_inner.pack(expand=True)

                tk.Button(btn_inner, text="✎ Change",
                          command=lambda st_row=s: self.edit_single_student_dialog(st_row, render_student_cards, dash),
                          bg="#0284c7", fg="white", activebackground="#0369a1", font=("Arial", 8, "bold"),
                          relief="flat", padx=9, pady=4).pack(side="left", padx=(0, 5))

                tk.Button(btn_inner, text="🗑 Delete",
                          command=lambda st_row=s: permanently_delete_student(st_row),
                          bg="#dc2626", fg="white", activebackground="#b91c1c", font=("Arial", 8, "bold"),
                          relief="flat", padx=9, pady=4).pack(side="left")

        render_student_cards()
        return dash

    def edit_single_student_dialog(self, student_tuple, on_success_callback, parent_dash):
        old_name, old_usn, old_branch, old_sem, old_email = student_tuple

        win = tk.Toplevel(parent_dash)
        win.title(f"Modify Student: {old_name} ({old_usn})")
        win.configure(bg=BG)
        win.geometry("520x480")
        win.resizable(True, True)
        win.grab_set()

        tk.Label(win, text=f"EDIT STUDENT: {old_name.upper()}", bg=BG, fg="white",
                 font=("Arial", 13, "bold")).pack(pady=(16, 10))

        form = tk.Frame(win, bg=BG)
        form.pack(fill="x", padx=25, pady=4)
        form.grid_columnconfigure(1, weight=1)

        new_photo_path = tk.StringVar(value="")

        photo_holder = tk.Frame(form, bg=BG)
        photo_holder.grid(row=0, column=0, columnspan=2, pady=6)
        cur_pic = photo_for_student(old_name, old_usn)
        pic_lbl = tk.Label(photo_holder, bg=BG)
        pic_lbl.pack(side="left", padx=8)

        def update_preview_pic(p):
            if p and os.path.exists(p):
                try:
                    im = Image.open(p).convert("RGB")
                    im = ImageOps.fit(im, (50, 50), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
                    img_tk = ImageTk.PhotoImage(im)
                    pic_lbl.config(image=img_tk, text="")
                    pic_lbl.image = img_tk
                except Exception:
                    pic_lbl.config(text="Pic Error", fg=RED)
            else:
                pic_lbl.config(text="No Photo", fg=MUTED)

        update_preview_pic(cur_pic)

        def pick_new_photo():
            file_chosen = filedialog.askopenfilename(
                title="Select New Student Photo",
                filetypes=[("Image Files", "*.jpg;*.jpeg;*.png")],
                parent=win
            )
            if file_chosen:
                new_photo_path.set(file_chosen)
                update_preview_pic(file_chosen)

        tk.Button(photo_holder, text="📁 Replace Photo", command=pick_new_photo, bg="#334155", fg="white",
                  relief="flat", padx=10, pady=4, font=("Arial", 8, "bold")).pack(side="left", padx=8)

        entries = {}
        fields = [
            ("Student Name:", "name", old_name),
            ("USN:", "usn", old_usn),
            ("Branch:", "branch", old_branch),
            ("Semester:", "sem", old_sem),
            ("Student/Parent Gmail:", "email", old_email),
        ]

        for idx, (label_text, key, val) in enumerate(fields, 1):
            tk.Label(form, text=label_text, bg=BG, fg="white", font=("Arial", 9)).grid(row=idx, column=0, sticky="w", pady=5)
            e = tk.Entry(form, width=28, font=("Arial", 9))
            e.insert(0, val)
            e.grid(row=idx, column=1, sticky="ew", pady=5, padx=(10, 0), ipady=3)
            bind_clipboard_menu(e)
            entries[key] = e

        def save_changes():
            n = entries["name"].get().strip()
            u = entries["usn"].get().strip()
            b = entries["branch"].get().strip()
            s = entries["sem"].get().strip()
            em = entries["email"].get().strip()

            if not (n and u and b and s):
                messagebox.showerror("Validation Error", "Name, USN, Branch, and Semester cannot be empty.", parent=win)
                return

            if u.lower() != old_usn.lower():
                all_st = load_registered_students()
                for st in all_st:
                    if st[1].lower() == u.lower():
                        messagebox.showerror("USN Conflict", f"USN '{u}' already belongs to {st[0]}!", parent=win)
                        return

            all_rows = []
            with open("students.csv", "r", newline="", encoding="utf-8-sig") as f:
                for row in csv.reader(f):
                    if len(row) >= 2 and row[1].strip().lower() == old_usn.lower():
                        all_rows.append([n, u, b, s])
                    else:
                        all_rows.append(row[:4])

            with open("students.csv", "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerows(all_rows)

            conn = db_connect()
            conn.execute("DELETE FROM student_emails WHERE LOWER(usn)=LOWER(?)", (old_usn,))
            if em:
                conn.execute("INSERT OR REPLACE INTO student_emails(usn, email) VALUES(?,?)", (u.lower(), em))

            conn.execute("UPDATE attendance SET name=?, usn=?, branch=?, sem=? WHERE LOWER(usn)=LOWER(?)",
                         (n, u, b, s, old_usn))
            conn.commit()
            conn.close()

            old_folder = os.path.join("dataset", f"{old_name.strip().replace(' ', '_')}_{old_usn.strip()}")
            new_folder = os.path.join("dataset", f"{n.strip().replace(' ', '_')}_{u.strip()}")
            if os.path.isdir(old_folder):
                if old_folder != new_folder:
                    os.rename(old_folder, new_folder)
            else:
                os.makedirs(new_folder, exist_ok=True)

            if new_photo_path.get() and os.path.exists(new_photo_path.get()):
                dest_file = os.path.join(new_folder, "1.jpg")
                shutil.copy2(new_photo_path.get(), dest_file)

            win.destroy()
            messagebox.showinfo("Student Updated", f"Information for '{n}' ({u}) updated successfully!", parent=parent_dash)
            on_success_callback()

        field_order = ["name", "usn", "branch", "sem", "email"]
        for i, key in enumerate(field_order):
            if i < len(field_order) - 1:
                next_key = field_order[i + 1]
                entries[key].bind("<Return>", lambda e, nk=next_key: (entries[nk].focus_set(), "break")[1])
            else:
                entries[key].bind("<Return>", lambda e: (save_changes(), "break")[1])

        btn_box = tk.Frame(win, bg=BG)
        btn_box.pack(fill="x", padx=25, pady=(18, 10))
        tk.Button(btn_box, text="Cancel", command=win.destroy, bg="#334155", fg="white",
                  relief="flat", padx=14, pady=6).pack(side="right", padx=(6, 0))
        tk.Button(btn_box, text="💾 Save Changes", command=save_changes, bg="#0284c7", fg="white",
                  font=("Arial", 9, "bold"), relief="flat", padx=16, pady=6).pack(side="right")

    # ------------------ WORKING PRINT REPORT (SINGLE-PAGE FLOW) ------------------
    def print_report(self, on_close_callback):
        dialog = tk.Toplevel(self.window)
        dialog.title("Print Attendance Report")
        dialog.configure(bg=BG)
        dialog.geometry("500x340")
        dialog.resizable(True, True)

        tk.Label(dialog, text="PRINT ATTENDANCE REPORT", bg=BG, fg="white",
                 font=("Arial", 15, "bold")).pack(pady=(18, 12))
        form = tk.Frame(dialog, bg=BG)
        form.pack(fill="x", padx=24)

        tk.Label(form, text="Report period", bg=BG, fg="white").grid(row=0, column=0, sticky="w", pady=7)
        period_var = tk.StringVar(value="Day")
        period_box = ttk.Combobox(form, textvariable=period_var, state="readonly", width=22,
                                  values=["Day", "Week", "Month", "Year", "All Attendance"])
        period_box.grid(row=0, column=1, sticky="ew", pady=7)

        default_anchor = date.today()
        entered_date = self.entries["date"].get().strip()
        if entered_date:
            try:
                default_anchor = date.fromisoformat(parse_date(entered_date))
            except ValueError:
                pass
        elif hasattr(self, "selected_day"):
            default_anchor = self.selected_day

        tk.Label(form, text="Date / period anchor", bg=BG, fg="white").grid(row=1, column=0, sticky="w", pady=7)
        anchor_var = tk.StringVar(value=default_anchor.strftime("%d-%m-%Y"))
        anchor_entry = tk.Entry(form, textvariable=anchor_var, width=24)
        anchor_entry.grid(row=1, column=1, sticky="ew", pady=7)
        bind_clipboard_menu(anchor_entry)

        tk.Label(form, text="Use DD-MM-YYYY. Week starts Monday (7 days); year/month use calendar days.",
                 bg=BG, fg=MUTED, wraplength=420, justify="left").grid(row=2, column=0, columnspan=2, sticky="w", pady=(0, 8))

        filtered_var = tk.BooleanVar(value=any(self.entries[k].get().strip() for k in ("name", "usn", "branch", "sem")))
        tk.Checkbutton(dialog, text="Use current student search filters (otherwise print all students)",
                       variable=filtered_var, bg=BG, fg="white", selectcolor=PANEL,
                       activebackground=BG, activeforeground="white", wraplength=420,
                       justify="left").pack(anchor="w", padx=24, pady=(3, 8))

        buttons = tk.Frame(dialog, bg=BG)
        buttons.pack(fill="x", padx=24, pady=(10, 16))
        tk.Button(buttons, text="← Back to Main", command=lambda: (dialog.destroy(), on_close_callback()),
                  bg="#334155", fg="white", relief="flat", padx=16, pady=7).pack(side="right", padx=(6, 0))

        def generate_report():
            try:
                anchor = date.fromisoformat(parse_date(anchor_var.get()))
            except ValueError as exc:
                messagebox.showerror("Invalid date", str(exc), parent=dialog)
                return

            period = period_var.get()
            if period == "Day":
                start_day = end_day = anchor
                period_label = f"Daily (1 Day) — {anchor.strftime('%d-%m-%Y')} ({anchor.strftime('%A')})"
            elif period == "Week":
                start_day = anchor - timedelta(days=anchor.weekday())
                end_day = start_day + timedelta(days=6)
                period_label = f"Weekly (7 Days: 6 Working, 1 Holiday) — {start_day.strftime('%d-%m-%Y')} to {end_day.strftime('%d-%m-%Y')}"
            elif period == "Month":
                days_in_m = calendar.monthrange(anchor.year, anchor.month)[1]
                start_day = anchor.replace(day=1)
                end_day = anchor.replace(day=days_in_m)
                period_label = f"Monthly ({days_in_m} Days) — {calendar.month_name[anchor.month]} {anchor.year}"
            elif period == "Year":
                start_day, end_day = date(anchor.year, 1, 1), date(anchor.year, 12, 31)
                yr_days = 366 if calendar.isleap(anchor.year) else 365
                period_label = f"Yearly ({yr_days} Days) — {anchor.year}"
            else:
                start_day, end_day = date(2000, 1, 1), date.today()
                period_label = f"All Attendance — {start_day.strftime('%d-%m-%Y')} to {end_day.strftime('%d-%m-%Y')}"

            students = sorted(load_registered_students(), key=usn_sort_key)
            if filtered_var.get():
                students = [student for student in students if self._matches_filters(student)]
            if not students:
                messagebox.showinfo("No students", "No registered students match the selected search filters.", parent=dialog)
                return

            att_map = get_attendance_map(start_day, end_day)
            attendance_dates_set = get_attendance_dates()
            report_rows = []
            d = start_day
            while d <= end_day:
                for student in students:
                    status, time_val, _ = determine_status_and_time(
                        student[0], student[1], d, att_map, attendance_dates_set
                    )
                    s_email = student[4] if len(student) >= 5 else ""
                    report_rows.append([student[0], student[1], student[2], student[3],
                                        format_date(d.isoformat()), status, time_val, s_email])
                d += timedelta(days=1)

            title = f"{period_label} Attendance Report"
            self.last_report = (title, ["Name", "USN", "Branch", "Semester", "Date", "Status", "Time", "Gmail"], report_rows)
            dialog.destroy()
            on_close_callback()
            open_print_report(title, self.last_report[1], report_rows)

        tk.Button(buttons, text="Generate & Print", command=generate_report, bg="#6d28d9", fg="white",
                  relief="flat", padx=16, pady=7).pack(side="right")
        return dialog


if __name__ == "__main__":
    if "--auto-absent" in sys.argv:
        run_headless_auto_absent_dispatch(mode="AUTO")
        sys.exit(0)

    root = tk.Tk()
    app = AttendanceApp(root)
    root.mainloop()