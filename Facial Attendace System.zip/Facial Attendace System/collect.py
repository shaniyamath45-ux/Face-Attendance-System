import cv2
import face_recognition
import pickle
import os
import shutil
from tkinter import messagebox

def open_camera():
    for i in (0, 1, 2):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            return cap
        cap.release()
    return None

def train_encodings():
    """Reads all student images from dataset/ and saves encodings.pickle."""
    dataset_dir = "dataset"
    if not os.path.exists(dataset_dir):
        return
    known_encodings = []
    known_names = []
    for folder in os.listdir(dataset_dir):
        folder_path = os.path.join(dataset_dir, folder)
        if not os.path.isdir(folder_path):
            continue
        for file in os.listdir(folder_path):
            if file.lower().endswith((".jpg", ".jpeg", ".png")):
                img_path = os.path.join(folder_path, file)
                try:
                    img = face_recognition.load_image_file(img_path)
                    encs = face_recognition.face_encodings(img)
                    if encs:
                        known_encodings.append(encs[0])
                        known_names.append(folder)
                except Exception:
                    continue
    with open("encodings.pickle", "wb") as f:
        pickle.dump({"encodings": known_encodings, "names": known_names}, f)
    print("Model trained and encodings.pickle updated successfully.")

def check_face_duplicate(encoding, threshold=0.48):
    """
    Checks if the detected face encoding already matches someone in encodings.pickle.
    Returns (True, registered_name, registered_usn) if matched, else (False, "", "").
    """
    if not os.path.exists("encodings.pickle"):
        return False, "", ""
    try:
        with open("encodings.pickle", "rb") as f:
            data = pickle.load(f)
        known_encodings = data.get("encodings", [])
        known_names = data.get("names", [])
        if not known_encodings:
            return False, "", ""
        distances = face_recognition.face_distance(known_encodings, encoding)
        if len(distances):
            idx = distances.argmin()
            if distances[idx] < threshold:
                matched_id = known_names[idx]
                parts = matched_id.split("_")
                usn = parts[-1] if len(parts) >= 2 else ""
                name = " ".join(parts[:-1]) if len(parts) >= 2 else matched_id
                return True, name, usn
    except Exception as e:
        print("Error checking duplicate:", e)
    return False, "", ""

def remove_from_students_csv(usn_to_remove):
    """If registration is cancelled because duplicate face was found, remove the unverified row from students.csv."""
    import csv
    if not os.path.exists("students.csv"):
        return
    try:
        rows = []
        with open("students.csv", "r", newline="", encoding="utf-8-sig") as f:
            for row in csv.reader(f):
                if len(row) >= 2 and row[1].strip().lower() == usn_to_remove.strip().lower():
                    continue
                rows.append(row)
        with open("students.csv", "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerows(rows)
    except Exception as e:
        print("Error updating students.csv:", e)

def collect_data(name, usn, branch, sem, email=""):
    """
    Collects face images for a student while verifying their face is not already registered under another name.
    """
    name_clean = name.strip().replace(" ", "_")
    usn_clean = usn.strip()
    student_id = f"{name_clean}_{usn_clean}"
    folder = os.path.join("dataset", student_id)

    cap = open_camera()
    if cap is None:
        messagebox.showerror("Camera Error", "Could not open camera. Please check your webcam connection.")
        remove_from_students_csv(usn_clean)
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    window_name = f"Registering: {name} ({usn})"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 900, 600)

    count = 0
    max_photos = 30
    temp_folder = os.path.join("dataset", f"temp_{student_id}")
    os.makedirs(temp_folder, exist_ok=True)

    verified_new_face = False
    duplicate_detected = False
    existing_name = ""
    existing_usn = ""

    print(f"Starting face collection for {name} ({usn}). Look at the camera...")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                continue

            display = frame.copy()
            small = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
            boxes = face_recognition.face_locations(rgb, model="hog")

            if boxes:
                box = boxes[0]
                top, right, bottom, left = [v * 2 for v in box]

                # 1. DUPLICATE CHECK: Verify the face on the very first detection
                if not verified_new_face:
                    face_encs = face_recognition.face_encodings(rgb, [box])
                    if face_encs:
                        is_dup, ex_name, ex_usn = check_face_duplicate(face_encs[0])
                        # If face matches someone else with a different USN
                        if is_dup and ex_usn.lower() != usn_clean.lower():
                            duplicate_detected = True
                            existing_name = ex_name
                            existing_usn = ex_usn
                            break
                        else:
                            verified_new_face = True

                # 2. Capture face crop
                face_crop = frame[max(0, top - 20):min(frame.shape[0], bottom + 20),
                                  max(0, left - 20):min(frame.shape[1], right + 20)]
                if face_crop.size > 0:
                    count += 1
                    cv2.imwrite(os.path.join(temp_folder, f"{count}.jpg"), face_crop)

                cv2.rectangle(display, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.putText(display, f"Capturing: {count}/{max_photos}", (left, max(25, top - 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            else:
                cv2.putText(display, "Please show your face to the camera", (40, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

            cv2.imshow(window_name, display)
            if cv2.waitKey(100) & 0xFF == ord('q') or count >= max_photos:
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()

    # If duplicate detected, cancel and show warning dialog
    if duplicate_detected:
        if os.path.exists(temp_folder):
            shutil.rmtree(temp_folder)
        remove_from_students_csv(usn_clean)
        warning_msg = (f"FACE ALREADY REGISTERED!\n\n"
                       f"This face already belongs to:\n"
                       f"Name: {existing_name}\n"
                       f"USN: {existing_usn}\n\n"
                       f"I don't want to add you again. You are already added!")
        messagebox.showerror("Duplicate Face Detected", warning_msg)
        return

    # If successful collection:
    if count >= 10:
        if os.path.exists(folder):
            shutil.rmtree(folder)
        os.rename(temp_folder, folder)
        # Retrain encodings with new face
        train_encodings()
        messagebox.showinfo("Success", f"Student '{name}' ({usn}) successfully registered and trained!")
    else:
        if os.path.exists(temp_folder):
            shutil.rmtree(temp_folder)
        remove_from_students_csv(usn_clean)
        messagebox.showwarning("Cancelled", "Registration cancelled or not enough face samples captured.")