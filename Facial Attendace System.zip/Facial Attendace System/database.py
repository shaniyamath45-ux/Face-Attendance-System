import sqlite3

conn = sqlite3.connect("attendance.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS attendance (
    photo TEXT,
    name TEXT,
    usn TEXT,
    branch TEXT,
    sem TEXT,
    date TEXT,
    time TEXT
)
""")

conn.commit()
conn.close()

print("✅ Table created successfully (photo first)")