import cv2
import face_recognition
import pickle
import sqlite3
import csv
import os
from datetime import datetime
import tkinter as tk
from PIL import Image, ImageTk
import signal
import sys

attendance_list = []

def usn_sort_key(person):
    usn = str(person[1]).strip()
    number = "".join(char for char in usn if char.isdigit())
    return (0, int(number), usn.lower()) if number else (1, 0, usn.lower())

def normalize_student_key(name, usn):
    name = name.strip().lower().replace(" ", "_")
    return f"{name}_{usn.strip().lower()}"

def load_students():
    data = {}
    if os.path.exists("students.csv"):
        with open("students.csv", "r", newline="", encoding="utf-8-sig") as f:
            for row in csv.reader(f):
                # Compatible with both 4-column and 5-column (with email) CSV
                if len(row) >= 4 and row[0].strip() and row[1].strip():
                    name, usn, branch, sem_name = row[:4]
                    name, usn = name.strip().replace(" ", "_"), usn.strip()
                    data[normalize_student_key(name, usn)] = (branch.strip(), sem_name.strip())
    return data

def mark_attendance(name):
    if name == "Unknown":
        return
    parts = name.split("_")
    if len(parts) < 2:
        return
    usn = parts[-1].strip()
    n = "_".join(parts[:-1]).strip()
    students = load_students()
    key = normalize_student_key(n, usn)
    if key not in students:
        print("Student not found in students.csv:", name)
        return
    branch, sem_name = students[key]
    now = datetime.now()
    date_value = now.strftime("%Y-%m-%d")       # database format remains stable
    time_value = now.strftime("%I:%M:%S %p")    # 12-hour time with AM/PM
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS attendance (
        name TEXT, usn TEXT, branch TEXT, sem TEXT, date TEXT, time TEXT, photo TEXT)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS attendance_days
        (date TEXT PRIMARY KEY, started INTEGER NOT NULL DEFAULT 0,
         finalized INTEGER NOT NULL DEFAULT 0)""")
    cursor.execute("INSERT OR IGNORE INTO attendance_days(date,started,finalized) VALUES(?,1,0)", (date_value,))
    cursor.execute("UPDATE attendance_days SET started=1 WHERE date=?", (date_value,))
    cursor.execute("""SELECT COUNT(*) FROM attendance
        WHERE LOWER(name)=LOWER(?) AND LOWER(usn)=LOWER(?) AND date=?""",
        (n.replace("_", " "), usn, date_value))
    if cursor.fetchone()[0]:
        conn.close()
        print(f"{n.replace('_', ' ')} ({usn}) already attended today.")
        return
    folder = os.path.join("dataset", f"{n}_{usn}")
    photo = ""
    if os.path.isdir(folder):
        files = sorted(f for f in os.listdir(folder) if f.lower().endswith((".jpg", ".jpeg", ".png")))
        if files:
            photo = os.path.join(folder, files[0])
    cursor.execute("INSERT INTO attendance VALUES (?,?,?,?,?,?,?)",
                   (n.replace("_", " "), usn, branch, sem_name, date_value, time_value, photo))
    conn.commit()
    conn.close()
    record = (n.replace("_", " "), usn, branch, sem_name, photo, date_value, time_value)
    if not any(p[0].lower() == record[0].lower() and p[1].lower() == usn.lower() and p[5] == date_value for p in attendance_list):
        attendance_list.append(record)
    print(f"Saved attendance: {record[0]} ({usn}) at {time_value}")

def show_cards():
    win = tk.Toplevel()
    win.title("Student ID Cards")
    win.geometry("650x700")
    win.configure(bg="#0f172a")
    canvas = tk.Canvas(win, bg="#0f172a")
    scrollbar = tk.Scrollbar(win, orient="vertical", command=canvas.yview)
    frame = tk.Frame(canvas, bg="#0f172a")
    frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    for person in sorted(attendance_list, key=usn_sort_key):
        name, usn, branch, sem_name, photo, date_value, time_value = person
        card = tk.Frame(frame, bg="#1e293b", bd=3, relief="ridge")
        card.pack(padx=15, pady=15, fill="x")
        tk.Label(card, text="STUDENT ID CARD", bg="#0ea5e9", fg="white",
                 font=("Arial", 14, "bold")).pack(fill="x")
        body = tk.Frame(card, bg="#1e293b")
        body.pack(padx=10, pady=10)
        if photo and os.path.exists(photo):
            img = ImageTk.PhotoImage(Image.open(photo).resize((130, 130)))
            lbl = tk.Label(body, image=img, bg="#1e293b")
            lbl.image = img
            lbl.grid(row=0, column=0, rowspan=6, padx=10)
        else:
            tk.Label(body, text="No Photo", fg="white", bg="#1e293b").grid(row=0, column=0)
        details = [name.upper(), f"USN: {usn}", f"Branch: {branch}", f"Semester: {sem_name}",
                   f"Date: {datetime.strptime(date_value, '%Y-%m-%d').strftime('%d-%m-%Y')}",
                   f"Time: {time_value}"]
        for i, value in enumerate(details):
            tk.Label(body, text=value, fg="#38bdf8" if i == 0 else "white", bg="#1e293b",
                     font=("Arial", 16, "bold") if i == 0 else ("Arial", 10)).grid(row=i, column=1, sticky="w")

def show_results():
    if not attendance_list:
        print("No new students detected in this session.")
        return
    print("\nATTENDANCE LIST")
    for person in sorted(attendance_list, key=usn_sort_key):
        name, usn, branch, sem, _, day, tm = person
        print(f"{name} | {usn} | {branch} | {sem} | {day} | {tm}")
    show_cards()

def handle_exit(signal_number, frame):
    print("\nCtrl+C pressed")
    show_results()
    sys.exit(0)

signal.signal(signal.SIGINT, handle_exit)

def open_camera():
    for i in (0, 1, 2):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"Camera opened at index {i}")
            return cap
        cap.release()
    print("Camera not working")
    return None

def start_attendance():
    attendance_list.clear()
    now = datetime.now()
    if now.hour < 7 or now.hour >= 23:
        print("Attendance is available from 7:00 AM to 11:00 PM.")
        return
    if not os.path.exists("encodings.pickle"):
        print("No trained data found. Register students first.")
        return
    with open("encodings.pickle", "rb") as f:
        data = pickle.load(f)
    known_encodings = data.get("encodings", [])
    known_names = data.get("names", [])
    students = load_students()
    valid = []
    for i, saved_name in enumerate(known_names):
        parts = saved_name.split("_")
        if len(parts) >= 2 and normalize_student_key("_".join(parts[:-1]), parts[-1]) in students:
            valid.append(i)
    known_encodings = [known_encodings[i] for i in valid]
    known_names = [known_names[i] for i in valid]
    if not known_encodings:
        print("No valid face encodings found.")
        return
    cap = open_camera()
    if cap is None:
        return
    day_conn = sqlite3.connect("attendance.db")
    day_conn.execute("""CREATE TABLE IF NOT EXISTS attendance_days
        (date TEXT PRIMARY KEY, started INTEGER NOT NULL DEFAULT 0,
         finalized INTEGER NOT NULL DEFAULT 0)""")
    day_conn.execute("INSERT OR IGNORE INTO attendance_days(date,started,finalized) VALUES(?,1,0)",
                     (datetime.now().strftime("%Y-%m-%d"),))
    day_conn.execute("UPDATE attendance_days SET started=1 WHERE date=?", (datetime.now().strftime("%Y-%m-%d"),))
    day_conn.commit()
    day_conn.close()
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    try:
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    except Exception:
        pass
    window_name = "Attendance System"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 1280, 720)
    fullscreen = False
    marked = set()
    frame_count = 0
    last_results = []
    print("Attendance started. Press Q to stop; F toggles fullscreen.")
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            frame_count += 1
            display_frame = frame.copy()
            if frame_count % 3 == 0:
                small = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
                rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
                boxes = face_recognition.face_locations(rgb, model="hog")
                encodings = face_recognition.face_encodings(rgb, boxes)
                results = []
                for box, encoding in zip(boxes, encodings):
                    top, right, bottom, left = [v * 2 for v in box]
                    name, usn, full_name = "Unknown", "", "Unknown"
                    if known_encodings:
                        distances = face_recognition.face_distance(known_encodings, encoding)
                        if len(distances):
                            idx = distances.argmin()
                            if distances[idx] < 0.5:
                                full_name = known_names[idx]
                                parts = full_name.split("_")
                                if len(parts) >= 2:
                                    usn = parts[-1]
                                    name = " ".join(parts[:-1])
                    results.append((left, top, right, bottom, name, usn, full_name))
                    if name != "Unknown" and full_name not in marked:
                        mark_attendance(full_name)
                        marked.add(full_name)
                last_results = results
            for left, top, right, bottom, name, usn, _ in last_results:
                color = (0, 255, 0) if name != "Unknown" else (0, 0, 255)
                label = f"{name} ({usn})" if name != "Unknown" else "Unknown"
                cv2.rectangle(display_frame, (left, top), (right, bottom), color, 2)
                y = top - 10 if top >= 25 else bottom + 25
                cv2.putText(display_frame, label, (left, y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
            cv2.imshow(window_name, display_frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if key == ord("f"):
                fullscreen = not fullscreen
                cv2.setWindowProperty(window_name, cv2.WND_PROP_FULLSCREEN,
                                      cv2.WINDOW_FULLSCREEN if fullscreen else cv2.WINDOW_NORMAL)
    finally:
        cap.release()
        cv2.destroyAllWindows()
    show_results()