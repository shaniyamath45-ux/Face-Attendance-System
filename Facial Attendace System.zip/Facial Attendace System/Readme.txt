                        FACE ATTENDANCE MANAGEMENT SYSTEM

Complete Installation, Configuration, Testing & User Manual

Project: Face Attendance Management System
Platform: Windows 10 / Windows 11
Programming Language: Python
IDE: Visual Studio Code
Database: SQLite
Face Recognition: OpenCV, dlib and face_recognition

---

TABLE OF CONTENTS

1. Project Overview
2. Software Requirements
3. Download and Install Python
4. Download and Install CMake
5. Download and Install Microsoft C++ Build Tools
6. Download and Install Visual Studio Code
7. Install VS Code Extensions
8. Extract and Open the Project
9. Create a Python Virtual Environment
10. Install All Required Python Libraries
11. Verify Library Installation
12. Run the Face Attendance System
13. How to Test the Project
14. How to Use the Attendance System
15. Database and Student Data
16. Admin Login Credentials
17. Gmail and App Password Configuration
18. Troubleshooting Common Errors

---

SECTION 1: PROJECT OVERVIEW

The Face Attendance Management System is a Python-based application that uses facial recognition technology to automatically identify students and record their attendance.

Main Features

- Face detection and recognition.
- Student registration.
- Face image collection.
- Automatic attendance recording.
- SQLite database management.
- Student information management.
- Daily, weekly, monthly and yearly attendance records.
- Attendance percentage calculation.
- Attendance graphs.
- PDF attendance reports.
- Automated absentee email notifications.
- Student search and filtering.
- Admin-controlled student management.

Main Python Files

The project contains four main Python files:

File Name| Purpose
gui.py| Main graphical user interface
main.py| Face recognition and attendance processing
collect.py| Student registration and face image collection
database.py| Database creation and attendance management

---

SECTION 2: SOFTWARE REQUIREMENTS

Before running the project, download and install the following software.

Software| Purpose
Python 3.10 (64-bit)| Runs the Python application
CMake| Configures C++ build processes
Microsoft C++ Build Tools| Provides the C++ compiler
Visual Studio Code| Used to edit and run Python files

Recommended System Requirements

- Operating System: Windows 10 or Windows 11 (64-bit).
- RAM: Minimum 8 GB recommended.
- Python: 3.10 (64-bit).
- Webcam: Required for face detection.
- Internet: Required for downloading software and libraries.
- Storage: Sufficient free disk space for the Python environment and student images.

---

SECTION 3: DOWNLOAD AND INSTALL PYTHON

Python is the main programming language used to develop and execute this project.

Step 1: Download Python

Official Website:

https://www.python.org/downloads/

1. Open the official Python website.
2. Find Python 3.10.
3. Download the Windows 64-bit installer.
4. Open the downloaded installer.

Step 2: Install Python

1. Double-click the downloaded installer.

2. IMPORTANT: Tick the checkbox:
   
   Add Python to PATH

3. Click Install Now.

4. Wait until the installation finishes.

5. Click Close.

Step 3: Verify Python Installation

Open Command Prompt or VS Code Terminal.

Execute:

python --version

Then execute:

pip --version

If the Python version appears, installation is successful.

---

SECTION 4: DOWNLOAD AND INSTALL CMAKE

CMake is a build configuration tool used to prepare and manage the compilation of C++ software.

It is useful when installing Python packages that contain C++ components, such as dlib, from source.

Step 1: Download CMake

Official Website:

https://cmake.org/download/

1. Open the official CMake website.
2. Find the latest stable release.
3. Locate the Windows x64 Installer.
4. Download the .msi installer.

Step 2: Install CMake

1. Open the downloaded installer.

2. Click Next.

3. Accept the license agreement.

4. Select the option:
   
   Add CMake to the system PATH for all users
   
   Alternatively, select the current-user PATH option if you do not have administrator permissions.

5. Click Next.

6. Click Install.

7. Wait for installation to finish.

8. Click Finish.

Step 3: Verify CMake

Open a new terminal and execute:

cmake --version

If the installed CMake version appears, installation is successful.

---

SECTION 5: DOWNLOAD AND INSTALL MICROSOFT C++ BUILD TOOLS

Microsoft C++ Build Tools provides the compiler and development components required to compile C++ extensions.

It can be required when a Python package does not provide a compatible precompiled Windows version.

Step 1: Download Microsoft C++ Build Tools

Official Microsoft Website:

https://visualstudio.microsoft.com/downloads/

1. Open the official Microsoft website.
2. Scroll down to Tools for Visual Studio.
3. Find Build Tools for Visual Studio.
4. Click Download.
5. Open the downloaded installer.
6. Wait for the Visual Studio Installer to load.

Step 2: Select the Required Workload

In the Workloads section, select:

Desktop development with C++

Step 3: Check the Required Components

Make sure the following components are selected:

1. MSVC C++ x64/x86 Build Tools.
2. Windows 10 or Windows 11 SDK.
3. C++ CMake tools for Windows.
4. MSBuild.

Step 4: Install Build Tools

1. Click Install.
2. Wait for the installation to complete.
3. Restart your laptop if requested.

Step 5: Verify Microsoft C++ Compiler

Open Developer Command Prompt for Visual Studio.

Execute:

cl

If Microsoft C/C++ compiler information appears, installation is successful.

Important: CMake and Microsoft C++ Build Tools are mainly needed when compiling dlib from source. Your primary installation command uses dlib-bin, which is intended to provide a precompiled Windows package. Try that first before attempting a source build.

---

SECTION 6: DOWNLOAD AND INSTALL VISUAL STUDIO CODE

Visual Studio Code is used to open, edit, manage and execute the Python project.

Step 1: Download VS Code

Official Website:

https://code.visualstudio.com/

1. Open the official website.
2. Click Download for Windows.
3. Download the Windows installer.
4. Open the installer.
5. Accept the agreement.
6. Click Next.
7. Complete the installation.

Step 2: Open VS Code

1. Launch Visual Studio Code.
2. Click File.
3. Select Open Folder.
4. Locate your extracted Face_Attendance_System folder.
5. Click Select Folder.

Your project will now appear in the VS Code Explorer.

---

SECTION 7: INSTALL VS CODE EXTENSIONS

Open VS Code.

Press:

Ctrl + Shift + X

Search for and install the following extensions.

Recommended Extensions

1. Python — Microsoft

Purpose: Python language support and execution.

2. Pylance — Microsoft

Purpose: Code completion, IntelliSense and error checking.

3. Python Debugger — Microsoft

Purpose: Debugging Python applications.

4. Python Environments — Microsoft

Purpose: Managing Python environments.

5. Rainbow CSV — mechatroner

Purpose: Viewing and managing CSV student records.

6. SQLite Viewer — Florian Klampfer

Purpose: Viewing database tables inside VS Code.

These extensions improve development and debugging. They are not all compulsory for running the application.

---

SECTION 8: EXTRACT AND OPEN THE PROJECT

Before opening the project in VS Code, complete the following steps in File Explorer or File Manager.

Step 1: Locate the ZIP File

1. Open File Explorer or File Manager.
2. Locate the downloaded Face_Attendance_System ZIP file.
3. Right-click the ZIP file.
4. Select Extract All.
5. Choose Desktop or another suitable location.
6. Click Extract.
7. Open the extracted project folder.

Step 2: Run setup.bat

The project folder may contain a file named setup.bat. This file can automatically create the virtual environment and install the required dependencies.

1. Open the extracted Face_Attendance_System folder in File Explorer or File Manager.
2. Locate setup.bat.
3. Double-click setup.bat.
4. Wait for the setup process to finish.
5. Follow any instructions displayed in the command window.
6. If setup.bat completes successfully, use start_app.bat, if available, to launch the application.

If setup.bat does not work, use the manual installation instructions in Sections 9–12. These instructions provide a backup method for creating the environment, installing all dependencies and configuring the project.

Recommended Folder Structure

Face_Attendance_System/
|
|-- gui.py
|-- main.py
|-- collect.py
|-- database.py
|-- setup.bat
|-- start_app.bat
|
|-- dataset/
|
|-- attendance.db
|
|-- students.csv
|
|-- venv/

Some files and folders may be generated automatically during installation or the first application run.

---

SECTION 9: CREATE A PYTHON VIRTUAL ENVIRONMENT

If setup.bat did not work, use the following manual backup configuration.

A virtual environment keeps all project libraries separate from the main Python installation.

Step 1: Open VS Code Terminal

Press:

Ctrl + `

Alternatively:

Terminal → New Terminal.

Make sure the terminal is opened inside your project folder.

Step 2: Create Virtual Environment

Execute:

python -m venv venv

Wait until the venv folder is created.

Step 3: Activate Virtual Environment

Execute:

venv\Scripts\activate

After successful activation, the terminal should display:

(venv)

If PowerShell Shows an Execution Policy Error

Execute:

Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

Press Y if prompted.

Then activate again:

venv\Scripts\activate

Step 4: Upgrade pip

Execute:

python -m pip install --upgrade pip setuptools wheel

Wait for the upgrade to finish.

---

SECTION 10: INSTALL ALL REQUIRED PYTHON LIBRARIES

Make sure your virtual environment is activated before installing libraries.

The following packages are used by the project.

Library| Purpose
Pillow| Image processing and thumbnails
Matplotlib| Attendance graphs
OpenCV| Webcam capture and image processing
NumPy| Numerical operations
dlib-bin| Precompiled dlib backend for supported Windows environments
face_recognition| Face encoding and recognition
face_recognition_models| Pre-trained face recognition models
Click| Command-line helper dependency

ONE-COMMAND INSTALLATION

Copy the complete command below and paste it into your VS Code terminal.

python -m pip install pillow matplotlib opencv-python numpy dlib-bin face_recognition_models Click && python -m pip install face-recognition --no-deps

Press Enter and wait for the installation to complete.

Important installation notes:

- Keep the virtual environment activated.
- Do not close the terminal during installation.
- Make sure your internet connection is working.
- If dlib-bin does not have a compatible package for your Python version, installation may fail.
- If dlib-bin fails, check its compatibility before attempting to compile dlib from source using CMake and Microsoft C++ Build Tools.

Built-in Python Libraries

The following libraries are already included with Python.

Do not install them using pip.

tkinter
sqlite3
csv
smtplib
ssl
email
datetime
calendar
threading
subprocess
pickle
os
shutil
io
base64
tempfile
webbrowser

---

SECTION 11: VERIFY LIBRARY INSTALLATION

After installing the libraries, verify that they are working.

Copy and execute:

python -c "import cv2, numpy, PIL, matplotlib, dlib, face_recognition; print('ALL LIBRARIES INSTALLED SUCCESSFULLY')"

Expected output:

ALL LIBRARIES INSTALLED SUCCESSFULLY

If you see this message without errors, the main libraries are ready.

You can also check installed packages using:

python -m pip list

---

SECTION 12: RUN THE FACE ATTENDANCE SYSTEM

Before launching the application:

1. Make sure the virtual environment is activated.
2. Check that all required libraries are installed.
3. Make sure your webcam is connected.
4. Check that the project files are available.

Step 1: Create Dataset Folder

Execute:

mkdir dataset

If the folder already exists, you do not need to create it again.

Step 2: Run the Application

Execute:

python gui.py

The Face Attendance Management System graphical interface should open.

Alternative: Automatic Setup

If your project includes setup.bat:

1. Open File Explorer or File Manager.
2. Navigate to the project folder.
3. Double-click setup.bat.
4. Wait for the installation process.
5. Follow the on-screen instructions.

After successful setup, use start_app.bat to launch the application, if it is included.

If setup.bat does not work, return to Sections 9–12 and complete the virtual environment creation, library installation, verification and application launch manually.

Note: The automatic setup file must contain the correct installation commands and project-specific dependencies.

---

SECTION 13: HOW TO TEST THE PROJECT

After launching the application, perform the following tests to confirm that the system is working correctly.

TEST 1: Check the Graphical User Interface

1. Run gui.py.
2. Wait for the main dashboard.
3. Check whether all buttons and menus are visible.
4. Navigate through the available sections.
5. Confirm that the application does not display unexpected errors.

Expected Result:

The main dashboard should open successfully.

TEST 2: Test Student Registration

1. Open the Add Student section.
2. Enter the student's name.
3. Enter the required student details, such as USN, branch and semester.
4. Start the webcam.
5. Capture the student's face samples.
6. Save the student information.

Expected Result:

The student's information and face images should be saved successfully.

TEST 3: Test Face Recognition

1. Register at least one student.
2. Open Start Attendance.
3. Allow webcam access.
4. Show the registered student's face to the camera.
5. Wait for the recognition process.

Expected Result:

The system should recognize the registered student.

TEST 4: Test Attendance Recording

1. Start the attendance process.
2. Present a registered student's face.
3. Allow the system to recognize the student.
4. Check whether attendance is recorded.
5. Open View Attendance.

Expected Result:

The recognized student's attendance should appear with the correct date and time.

TEST 5: Test Duplicate Attendance Prevention

1. Present the same registered student's face.
2. Allow attendance to be recorded.
3. Present the same face again on the same day.

Expected Result:

The system should not create duplicate attendance entries if duplicate prevention is enabled.

TEST 6: Test Attendance Filters

Open View Attendance.

Test the available filters:

- Today.
- This Week.
- This Month.
- This Year.
- All Records.

Also test student name, USN, branch, semester and date filters if available.

Expected Result:

The attendance records should be displayed according to the selected filters.

TEST 7: Test Attendance Reports

1. Open the attendance report section.
2. Select the required date range.
3. Check the attendance percentage.
4. Generate the attendance graph.
5. Generate the PDF report.

Expected Result:

The attendance graph and PDF report should be generated successfully.

TEST 8: Test Admin Login

1. Open Change Info.
2. Enter the administrator username and password.
3. Log in.
4. Check whether student management options are accessible.

Expected Result:

The admin should be able to access the authorized student management functions.

TEST 9: Test Email Notifications

1. Configure the Gmail address.
2. Enter the Google App Password.
3. Save the email settings.
4. Send a test report to an address you control, if the application supports test sending.
5. Check the recipient's inbox.

Expected Result:

The email should be delivered successfully.

---

SECTION 14: HOW TO USE THE ATTENDANCE SYSTEM

A. Add a New Student

1. Open the dashboard.
2. Click Add Student.
3. Enter the student information.
4. Capture face samples.
5. Save the details.

B. Start Attendance

1. Open Start Attendance.
2. Allow webcam access.
3. Position the student's face in front of the camera.
4. Wait for face recognition.
5. Check the attendance confirmation.

C. View Attendance

1. Open View Attendance.
2. Select the required date range.
3. Search for students.
4. View attendance records.
5. Check attendance percentages.

D. Manage Student Information

1. Open Change Info.
2. Enter administrator credentials.
3. Select the required student.
4. Update information, replace photos or delete the student as permitted.

---

SECTION 15: DATABASE AND STUDENT DATA

The project uses SQLite for storing student and attendance information.

Main database:

attendance.db

Student CSV file:

students.csv

Face image folder:

dataset/

Database Testing

1. Open VS Code.
2. Locate attendance.db.
3. Open it using SQLite Viewer.
4. Inspect the available database tables.
5. Check whether student and attendance records are being saved.

Important:

Do not manually modify or delete database records unless you understand the database structure.

Always maintain a backup of attendance.db and the dataset folder.

---

SECTION 16: ADMIN LOGIN CREDENTIALS

The default administrator credentials are:

Username: Kamran
Password: Kamran@123

How to Login

1. Open the application.
2. Click Change Info.
3. Enter the username.
4. Enter the password.
5. Click Login.

Security Recommendation:

Change the default administrator password before using the application in a real environment.

Do not share administrator credentials with unauthorized users.

---

SECTION 17: GMAIL AND APP PASSWORD CONFIGURATION

The application uses Gmail SMTP to send absentee notifications and attendance reports.

Google does not allow regular Gmail account passwords to be used for this purpose.

You need a Google App Password.

STEP 1: Open Google Account

Official Website:

https://myaccount.google.com/

STEP 2: Enable Two-Step Verification

1. Sign in to your Google Account.
2. Open Security.
3. Locate Two-Step Verification.
4. Enable it if it is not already enabled.

STEP 3: Generate an App Password

1. Search for App Passwords in your Google Account settings.

2. Open the App Passwords section.

3. Enter an application name, such as:
   
   Face Attendance System

4. Click Create.

5. Copy the generated 16-character password.

App Password availability depends on Google's account security requirements.

STEP 4: Configure Gmail in the Application

1. Open the Face Attendance System.
2. Click Inform Absentees.
3. Enter your Gmail address in Sender Admin Gmail.
4. Enter the generated App Password.
5. Set the automatic absentee dispatch time.
6. Enable automatic dispatch if required.
7. Click Save Settings.

HOW EMAIL SENDING WORKS

Automatic Absentee Alerts

- The system checks absent students.
- It sends notifications to students with registered email addresses.
- Duplicate notifications are prevented according to the application's daily tracking logic.

Manual Attendance Reports

1. Open Email Center.
2. Select the required students.
3. Choose the report period.
4. Select Today, This Week, This Month or This Year.
5. Click Send Report + Percentage Graph & PDF.

The application sends the attendance report and PDF attachment.

Security Warning: Never share your Gmail App Password with anyone. Store it securely and do not upload it to public GitHub repositories.

---

SECTION 18: TROUBLESHOOTING COMMON ERRORS

ERROR 1: Python Is Not Recognized

Possible Reason:

Python is not installed correctly or was not added to PATH.

Solution:

1. Reinstall Python.

2. Enable Add Python to PATH.

3. Restart the terminal.

4. Execute:
   
   python --version

ERROR 2: setup.bat Does Not Work

Possible Reasons:

- The batch file is blocked by Windows.
- The project folder path contains permission restrictions.
- Python is not installed or is not available in PATH.
- The setup commands are incompatible with your Python version.
- The computer is not connected to the internet.

Solution:

1. Open File Explorer or File Manager.
2. Right-click setup.bat and select Properties.
3. If an Unblock option appears, select it and click Apply.
4. Right-click the project folder and choose Open in Terminal.
5. Run setup.bat from